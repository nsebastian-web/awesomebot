<?php
/**
 * Plugin Name:       AwesomeBot
 * Description:       An AI-powered chatbot plugin integrated with Gemini, featuring customizable prompts and behavior, powered by RAG and Vector Search.
 * Version:           1.1.0
 * Author:            awesomemotive.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       awesomebot
 * Domain Path:       /languages
 * Requires PHP:      7.4
 * Requires at least: 5.8
 * Tested up to:      6.5
 * Stable tag:        1.1.0
 */

// Strict types declaration at the very beginning.
declare(strict_types=1);

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

// --- Constants ---
define('AWESOMEBOT_VERSION', '1.1.0');
define('AWESOMEBOT_DIR', plugin_dir_path(__FILE__));
define('AWESOMEBOT_URL', plugin_dir_url(__FILE__));
define('AWESOMEBOT_PLUGIN_FILE', __FILE__);
define('AWESOMEBOT_MIN_PHP_VERSION', '7.4');
define('AWESOMEBOT_MIN_WP_VERSION', '5.8');
define('AWESOMEBOT_DB_VERSION', '1.1'); // For tracking schema changes.

// --- PHP Version Check ---
if (version_compare(PHP_VERSION, AWESOMEBOT_MIN_PHP_VERSION, '<')) {
    add_action(
        'admin_notices',
        function () {
            printf(
                '<div class="notice notice-error"><p>%s</p></div>',
                sprintf(
                    /* translators: 1: Required PHP version, 2: Current PHP version */
                    esc_html__('AwesomeBot requires PHP version %1$s or later. You are running version %2$s. Please upgrade PHP or deactivate the plugin.', 'awesomebot'),
                    esc_html(AWESOMEBOT_MIN_PHP_VERSION),
                    esc_html(PHP_VERSION)
                )
            );
        }
    );
    // Prevent further plugin execution if PHP version is too low.
    return;
}

/**
 * Autoloader for AwesomeBot classes.
 * Loads classes prefixed with "AwesomeBot_" from the includes directory.
 * Follows PSR-4 like naming convention for files (class-awesomebot-class-name.php).
 *
 * @since 1.0.0
 * @param string $class_name The name of the class to load (e.g., AwesomeBot_Core).
 */
spl_autoload_register(
    function (string $class_name): void {
        // Only attempt to load classes starting with 'AwesomeBot_'.
        if (0 === strpos($class_name, 'AwesomeBot_')) {
            // Convert Class_Name to class-name (lowercase, underscores to hyphens).
            $file_name = 'class-' . strtolower(str_replace('_', '-', $class_name)) . '.php';
            $file_path = AWESOMEBOT_DIR . 'includes/' . $file_name;

            if (file_exists($file_path)) {
                require_once $file_path;
            }
            // Optional: Log missing class files only during debugging.
            // else { if (defined('WP_DEBUG') && WP_DEBUG) { error_log(sprintf('AwesomeBot autoloader: File not found for class %s at %s', $class_name, $file_path)); } }
        }
    }
);

// --- Dependency Checks & Includes ---

// Include Composer Autoloader.
if (file_exists(AWESOMEBOT_DIR . 'vendor/autoload.php')) {
    require_once AWESOMEBOT_DIR . 'vendor/autoload.php';
} else {
    add_action(
        'admin_notices',
        function () {
            // Only show on AwesomeBot pages or if specifically checking.
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($screen && isset($screen->id) && false !== strpos($screen->id, 'awesomebot')) {
                printf(
                    '<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
                    esc_html__('Warning: AwesomeBot requires Composer dependencies for full functionality (PDF, DOCX, URL processing). The vendor/autoload.php file was not found. Please run `composer install` in the plugin directory.', 'awesomebot')
                );
            }
        }
    );
}

// Include background job handlers. Critical dependency for processing.
if (file_exists(AWESOMEBOT_DIR . 'includes/background-jobs.php')) {
    require_once AWESOMEBOT_DIR . 'includes/background-jobs.php';
} else {
    add_action(
        'admin_notices',
        function () {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($screen && isset($screen->id) && false !== strpos($screen->id, 'awesomebot')) {
                printf(
                    '<div class="notice notice-error"><p>%s</p></div>',
                    esc_html__('Error: AwesomeBot background job handlers file (includes/background-jobs.php) is missing. Source processing will fail.', 'awesomebot')
                );
            }
        }
    );
}

/**
 * Main AwesomeBot Plugin Class (Singleton Pattern).
 *
 * Initializes the plugin, sets up hooks, handles activation/deactivation,
 * and checks for critical dependencies.
 *
 * @since 1.0.0
 */
final class AwesomeBot {

    /**
     * The single instance of the class.
     * @since 1.0.0
     * @var   AwesomeBot|null
     */
    private static ?AwesomeBot $instance = null;

    /**
     * Instance of the core functionality handler.
     * @since 1.1.0
     * @var   AwesomeBot_Core|null
     */
    public ?AwesomeBot_Core $core = null;

    /**
     * Instance of the frontend handler.
     * @since 1.1.0
     * @var   AwesomeBot_Frontend|null
     */
    public ?AwesomeBot_Frontend $frontend = null;

    /**
     * Instance of the admin handler.
     * @since 1.1.0
     * @var   AwesomeBot_Admin|null
     */
    public ?AwesomeBot_Admin $admin = null;


    /**
     * Gets the single instance of the AwesomeBot class.
     * Ensures only one instance exists.
     *
     * @since 1.0.0
     * @return AwesomeBot The single instance.
     */
    public static function get_instance(): AwesomeBot {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent direct instantiation.
     * Sets up hooks and initializes components.
     *
     * @since 1.0.0
     */
    private function __construct() {
        $this->check_dependencies(); // Perform critical dependency checks early.
        $this->init_hooks();
        $this->load_components();
    }

    /**
     * Checks for critical missing class dependencies.
     * Adds admin notices if core components are missing.
     *
     * @since 1.1.0
     * @return void
     */
    private function check_dependencies(): void {
        $missing_classes = [];
        if (!class_exists('AwesomeBot_Core')) { $missing_classes[] = 'AwesomeBot_Core'; }
        if (!class_exists('AwesomeBot_Sources')) { $missing_classes[] = 'AwesomeBot_Sources'; } // Needed by Core & Admin
        if (!class_exists('AwesomeBot_Frontend')) { $missing_classes[] = 'AwesomeBot_Frontend'; }
        if (is_admin() && !class_exists('AwesomeBot_Admin')) { $missing_classes[] = 'AwesomeBot_Admin'; }
        // Background jobs file is checked separately via hook.

        if (!empty($missing_classes)) {
            add_action(
                'admin_notices',
                function () use ($missing_classes) {
                    printf(
                        '<div class="notice notice-error"><p>%s</p><ul>%s</ul></div>',
                        esc_html__('Error: AwesomeBot is missing critical components and cannot function correctly. Please ensure all plugin files are present and correctly named. Missing classes:', 'awesomebot'),
                        '<li>' . implode('</li><li>', array_map('esc_html', $missing_classes)) . '</li>'
                    );
                }
            );
            // Prevent loading components if core parts are missing.
            $this->mark_as_broken();
        }
    }

    /**
     * Marks the plugin as broken to prevent further initialization.
     *
     * @since 1.1.0
     * @return void
     */
    private function mark_as_broken(): void {
        // We can set a flag or remove hooks, but since dependencies are checked
        // before components load, returning early from load_components is sufficient.
    }

    /**
     * Initializes WordPress hooks.
     *
     * @since 1.0.0
     * @return void
     */
    private function init_hooks(): void {
        register_activation_hook(AWESOMEBOT_PLUGIN_FILE, [__CLASS__, 'activate']); // Use static call for activation
        register_deactivation_hook(AWESOMEBOT_PLUGIN_FILE, [__CLASS__, 'deactivate']); // Use static call for deactivation

        // Load text domain if needed
        // add_action('plugins_loaded', [$this, 'load_textdomain']);

        // Check for Action Scheduler dependency
        add_action('admin_notices', [__CLASS__, 'check_action_scheduler_notice']);
    }

    /**
     * Loads and initializes the main plugin components (Core, Frontend, Admin).
     *
     * @since 1.1.0
     * @return void
     */
    private function load_components(): void {
        // Check if essential classes exist before instantiating.
        if (!class_exists('AwesomeBot_Core') || !class_exists('AwesomeBot_Sources')) {
             // Logged by check_dependencies
            return;
        }

        $this->core = new AwesomeBot_Core();

        if (class_exists('AwesomeBot_Frontend')) {
            $this->frontend = new AwesomeBot_Frontend();
        }

        if (is_admin() && class_exists('AwesomeBot_Admin')) {
            $this->admin = new AwesomeBot_Admin();
        }
    }

    /**
     * Loads the plugin textdomain for translation.
     *
     * @since 1.0.0
     * @return void
     */
    public function load_textdomain(): void {
        load_plugin_textdomain(
            'awesomebot',
            false,
            dirname(plugin_basename(AWESOMEBOT_PLUGIN_FILE)) . '/languages'
        );
    }

    /**
     * Plugin activation hook (static method).
     * Sets up default options and installs/updates the database schema.
     *
     * @since 1.0.0
     * @since 1.1.0 Refactored for clarity, added DB version tracking.
     * @return void
     */
    public static function activate(): void {
        // Set default General settings.
        $default_settings = apply_filters('awesomebot_default_settings', [
            'theme'         => 'default',
            'icon'          => 'default',
            'console_theme' => 'default',
            'uninstall'     => false, // Default to NOT deleting data on save.
        ]);
        add_option('awesomebot_settings', $default_settings, '', 'yes'); // Autoload settings

        // Set default Connect settings.
        $default_connect_options = apply_filters('awesomebot_default_connect_options', [
            'gemini_enabled' => true,
            'gemini_model'   => 'gemini-1.5-flash-latest',
        ]);
        add_option('awesomebot_connect_options', $default_connect_options, '', 'yes'); // Autoload connect options

        // Set default API keys and prompts (stored separately).
        add_option('awesomebot_gemini_api_key', '', '', 'no'); // No autoload for keys
        add_option('awesomebot_pinecone_settings', ['api_key' => '', 'index_host' => ''], '', 'no'); // No autoload for keys
        add_option('awesomebot_system_prompt', 'Be helpful and informative. Format your response clearly using Markdown.', '', 'yes'); // Autoload prompt
        add_option('awesomebot_support_email', get_option('admin_email', ''), '', 'yes'); // Autoload support email

        // Initialize options that store larger data, ensuring they exist (no autoload).
        add_option('awesomebot_chat_history', [], '', 'no');
        add_option('awesomebot_sources', [], '', 'no');
        add_option('awesomebot_logs', [], '', 'no');
        add_option('awesomebot_wp_content_sources', [], '', 'no'); // Use specific key for WP content IDs

        // Install/Update database schema.
        self::install_schema();

        // Store current plugin version.
        update_option('awesomebot_version', AWESOMEBOT_VERSION);
    }

    /**
     * Creates or updates custom database tables using dbDelta.
     * Checks database version to avoid unnecessary updates.
     *
     * @since 1.0.1
     * @since 1.1.0 Moved into separate static method, added version check.
     * @return void
     */
    public static function install_schema(): void {
        $installed_db_version = get_option('awesomebot_db_version', '0');

        // Only run dbDelta if the version has changed.
        if (version_compare($installed_db_version, AWESOMEBOT_DB_VERSION, '<')) {
            global $wpdb;

            // Ensure dbDelta function is available.
            if (!function_exists('dbDelta')) {
                require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            }

            $charset_collate = $wpdb->get_charset_collate();
            $meta_table_name = $wpdb->prefix . 'awesomebot_source_meta';
            $chunks_table_name = $wpdb->prefix . 'awesomebot_chunks';

            // Define table schemas. Added DEFAULT '' for robustness.
            // Consider adding indexes for frequently queried columns if performance dictates.
            $sql_meta = "CREATE TABLE {$meta_table_name} (
                meta_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                source_id BIGINT(20) UNSIGNED NOT NULL,
                source_type VARCHAR(20) NOT NULL DEFAULT '',
                original_ref TEXT NOT NULL,
                processing_status VARCHAR(20) NOT NULL DEFAULT 'pending',
                keywords TEXT DEFAULT NULL,
                last_processed DATETIME DEFAULT NULL,
                error_message TEXT DEFAULT NULL,
                PRIMARY KEY  (meta_id),
                KEY source_id_idx (source_id),
                KEY source_type_idx (source_type),
                KEY status_idx (processing_status)
            ) {$charset_collate};";

            $sql_chunks = "CREATE TABLE {$chunks_table_name} (
                chunk_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                meta_id BIGINT(20) UNSIGNED NOT NULL,
                chunk_order INT UNSIGNED NOT NULL DEFAULT 0,
                chunk_text LONGTEXT NOT NULL,
                embedding LONGTEXT DEFAULT NULL,
                PRIMARY KEY  (chunk_id),
                KEY meta_id_idx (meta_id)
            ) {$charset_collate};";

            // Execute dbDelta.
            dbDelta($sql_meta);
            dbDelta($sql_chunks);

            // Update the database version option.
            update_option('awesomebot_db_version', AWESOMEBOT_DB_VERSION);

            // Log schema update if logging is available at this stage.
            if (class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log')) {
                AwesomeBot_Logs::log("Database schema updated to version " . AWESOMEBOT_DB_VERSION, 'info');
            }
        }
    }

    /**
     * Plugin deactivation hook (static method).
     * Cleans up scheduled actions to prevent them from running when inactive.
     * Does NOT delete data here - deletion handled by user via settings.
     *
     * @since 1.0.0
     * @since 1.1.0 Ensured logging class check.
     * @return void
     */
    public static function deactivate(): void {
        // Clear scheduled actions if Action Scheduler is available.
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions('awesomebot_process_source_content', null, 'awesomebot_sources');
            as_unschedule_all_actions('awesomebot_process_wp_content', null, 'awesomebot_sources');
            as_unschedule_all_actions('awesomebot_generate_embeddings', null, 'awesomebot_embeddings');

            if (class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log')) {
                AwesomeBot_Logs::log('Cleared scheduled source processing/embedding actions on deactivation.', 'debug');
            }
        }
    }

    /**
     * Displays an admin notice if Action Scheduler library is missing.
     * Static method for use in hooks.
     *
     * @since 1.0.1
     * @return void
     */
    public static function check_action_scheduler_notice(): void {
        // Only show if Action Scheduler functions don't exist and user is on an AwesomeBot admin page.
        if (!function_exists('as_schedule_single_action')) {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($screen && isset($screen->id) && false !== strpos($screen->id, 'awesomebot')) {
                printf(
                    '<div class="notice notice-error is-dismissible"><p>%s</p></div>',
                    sprintf(
                        wp_kses(
                            /* translators: %s: Link to WordPress plugin repository search for Action Scheduler. */
                            __('Requirement Missing: <strong>AwesomeBot</strong> requires the <strong>Action Scheduler</strong> library for background processing of sources (Documents, URLs, WP Content). These features will be disabled until Action Scheduler is installed and activated. You can usually install it from the <a href="%s" target="_blank">WordPress.org plugin repository</a>.', 'awesomebot'),
                            ['strong' => [], 'a' => ['href' => [], 'target' => []]]
                        ),
                        esc_url('https://wordpress.org/plugins/search/action-scheduler/')
                    )
                );
            }
        }
    }

    /** Prevent cloning of the instance. */
    private function __clone() {}

    /** Prevent unserializing of the instance. */
    public function __wakeup() {}

} // End final class AwesomeBot.

/**
 * Begins execution of the plugin by getting the Singleton instance.
 * Ensures the plugin runs only once.
 *
 * @since 1.0.0
 * @return AwesomeBot The plugin instance.
 */
function awesomebot_run(): AwesomeBot {
    return AwesomeBot::get_instance();
}

// Initialize the plugin, but only if PHP version check passed.
if (version_compare(PHP_VERSION, AWESOMEBOT_MIN_PHP_VERSION, '>=')) {
    awesomebot_run();
}

// Note: No closing PHP tag needed.