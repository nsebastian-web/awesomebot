/**
 * AwesomeBot Frontend JavaScript
 *
 * Handles widget/console UI, AJAX requests (including conversation history),
 * message formatting (Markdown-like), typing effect, source indicators, ratings, transcripts.
 *
 * @since 1.0.0
 * @version 1.1.1
 * @package AwesomeBot
 */
jQuery(document).ready(function($) {

    // --- Configuration & State ---
    const ajax_url = window.awesomebot_data?.ajax_url;
    const widget_nonce = window.awesomebot_data?.nonce; // For widget requests
    const console_nonce = window.awesomebot_data?.console_nonce; // For console, rating, transcript requests
    const support_email = window.awesomebot_data?.support_email; // For transcript feature enablement
    const historyLimit = 10; // Max history items (user + model turns) to send to backend

    // Session-level storage for conversation history (Gemini format)
    let currentSessionHistory = []; // Array of {role: 'user'/'model', parts: [{text: '...'}]}

    // Check for essential configuration
    if (!ajax_url || !widget_nonce || !console_nonce) {
        console.error('AwesomeBot Error: Missing essential configuration data (AJAX URL or Nonces). Chat functionality may be impaired.');
        // Optionally display a persistent error message in chat interfaces if needed here
    }

    // --- Helper Functions ---

    /**
     * Basic HTML escaping.
     * @param {*} unsafe Input value.
     * @returns {string} Escaped string.
     */
    function escapeHtml(unsafe) {
        if (typeof unsafe !== 'string') {
            try { unsafe = String(unsafe); } catch (e) { return ''; }
        }
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return unsafe.replace(/[&<>"']/g, m => map[m]);
    }

    /**
     * Adds a turn to the session history, maintaining format and limit.
     * @param {string} role 'user' or 'model'.
     * @param {string} text The raw message text.
     */
    function addTurnToHistory(role, text) {
        if (role !== 'user' && role !== 'model') return;
        const trimmedText = text.trim();
        if (typeof text !== 'string' || trimmedText === '') return;

        currentSessionHistory.push({
            role: role,
            parts: [{ text: trimmedText }]
        });

        // Apply history limit rotation (FIFO)
        if (currentSessionHistory.length > historyLimit) {
            currentSessionHistory = currentSessionHistory.slice(-historyLimit);
        }
        // console.log("AwesomeBot History:", JSON.stringify(currentSessionHistory)); // Debugging
    }

    /**
     * Clears the session history array.
     */
    function clearSessionHistory() {
        currentSessionHistory = [];
        console.log("AwesomeBot: Session history cleared.");
    }

    /**
     * Formats bot message content (Markdown-like to HTML).
     * Handles paragraphs, lists, bold, italic, links.
     * @param {string} text Raw text message.
     * @return {string} HTML formatted message.
     */
    function formatMessageContent(text) {
        if (typeof text !== 'string') return '';
        let html = text.trim();

        // 1. Escape basic HTML characters first
        html = escapeHtml(html);

        // 2. Process blocks (paragraphs and lists) based on double newlines
        const blocks = html.split(/\n\s*\n+/); // Split by one or more empty lines
        let processedHtml = '';
        for (const block of blocks) {
            let trimmedBlock = block.trim();
            if (trimmedBlock.length === 0) continue;

            // Improved list detection (check first line)
            const firstLine = trimmedBlock.split('\n')[0].trim();
            const isUnorderedList = /^\s*(\*|-)\s+/.test(firstLine);
            const isOrderedList = /^\s*\d+\.\s+/.test(firstLine);

            if (isUnorderedList || isOrderedList) {
                let listTag = isOrderedList ? 'ol' : 'ul';
                let listHtml = `<${listTag}>`;
                const items = trimmedBlock.split('\n');
                for (const item of items) {
                    let listItemContent = item.trim();
                    // Remove list markers (*, -, 1.) for content processing
                    listItemContent = listItemContent.replace(/^\s*(\*|-|\d+\.)\s+/, '');
                    if (listItemContent) { // Only add if content exists after marker removal
                        // Apply inline formatting *inside* list item
                        // Bold: **text**
                        listItemContent = listItemContent.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
                        // Italic: *text* (avoiding ** and internal *)
                        listItemContent = listItemContent.replace(/(?<![a-zA-Z0-9*])\*(?![*\s])(.*?)(?<![\s*])\*(?![a-zA-Z0-9*])/g, '<i>$1</i>');
                        listHtml += `<li>${listItemContent}</li>`;
                    }
                }
                listHtml += `</${listTag}>`;
                processedHtml += listHtml;
            } else {
                // Process as a paragraph
                let paragraphContent = trimmedBlock;
                // Apply inline formatting
                // Bold: **text**
                paragraphContent = paragraphContent.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
                // Italic: *text*
                paragraphContent = paragraphContent.replace(/(?<![a-zA-Z0-9*])\*(?![*\s])(.*?)(?<![\s*])\*(?![a-zA-Z0-9*])/g, '<i>$1</i>');

                // Replace single newlines within the block with <br> for line breaks inside paragraphs
                paragraphContent = paragraphContent.replace(/\n/g, '<br>');
                processedHtml += `<p>${paragraphContent}</p>`;
            }
        }
        html = processedHtml;

        // 3. Convert standalone URLs to links (after other formatting)
        // Regex to find URLs starting with http/https, avoiding those already likely in attributes or tags
        const urlRegex = /(?<!["'=])(\bhttps?:\/\/[^\s"<>()`]+)/g;
        // Perform replacement carefully to avoid breaking existing HTML structure
        const parts = html.split(/(<[^>]+>)/); // Split by tags
        html = parts.map(part => {
            if (part.startsWith('<')) { return part; } // Keep tags as is
            return part.replace(urlRegex, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
        }).join('');

        // 4. Clean up potentially empty tags created by splitting logic
        html = html.replace(/<p>(\s*|<br\s*\/?>)*<\/p>/g, '');
        html = html.replace(/<(ul|ol)>(\s*|<br\s*\/?>)*<\/(ul|ol)>/g, '');

        return html;
    }

    /**
     * Displays bot message with typing effect (plain text), then formats.
     * Includes RAG indicator and rating options.
     * @param {jQuery} $container jQuery object of the message container.
     * @param {string} message Raw text message from the bot.
     * @param {number|string|null} chatId The ID of the chat entry for rating.
     * @param {boolean} is_rag Indicates if the response was RAG-based.
     */
    function typeMessage($container, message, chatId, is_rag) {
        if (typeof message !== 'string') { message = String(message); } // Ensure string

        const $msgDiv = $('<div class="bot-message"></div>');
        const uniqueId = 'awesomebot-msg-' + Date.now() + Math.random().toString(36).substring(2, 11);
        $msgDiv.attr('id', uniqueId);

        // --- Prepare Footer HTML (RAG indicator & Ratings) ---
        let footerHtml = '';
        if (is_rag) {
            footerHtml += '<span class="awesomebot-source-indicator" title="Answer based on provided sources">🧠 Sources</span>';
        }
        const validChatId = chatId !== null && typeof chatId !== 'undefined' && String(chatId).length > 0; // Check if ID is present
        if (validChatId) {
            const thumbsUpSvg = '<svg aria-label="Good Response" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-md-heavy thumbs-up" data-chat-id="' + escapeHtml(chatId) + '" title="Good Response"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.1318 2.50389C12.3321 2.15338 12.7235 1.95768 13.124 2.00775L13.5778 2.06447C16.0449 2.37286 17.636 4.83353 16.9048 7.20993L16.354 8.99999H17.0722C19.7097 8.99999 21.6253 11.5079 20.9313 14.0525L19.5677 19.0525C19.0931 20.7927 17.5124 22 15.7086 22H6C4.34315 22 3 20.6568 3 19V12C3 10.3431 4.34315 8.99999 6 8.99999H8C8.25952 8.99999 8.49914 8.86094 8.6279 8.63561L12.1318 2.50389ZM10 20H15.7086C16.6105 20 17.4008 19.3964 17.6381 18.5262L19.0018 13.5262C19.3488 12.2539 18.391 11 17.0722 11H15C14.6827 11 14.3841 10.8494 14.1956 10.5941C14.0071 10.3388 13.9509 10.0092 14.0442 9.70591L14.9932 6.62175C15.3384 5.49984 14.6484 4.34036 13.5319 4.08468L10.3644 9.62789C10.0522 10.1742 9.56691 10.5859 9 10.8098V19C9 19.5523 9.44772 20 10 20ZM7 11V19C7 19.3506 7.06015 19.6872 7.17071 20H6C5.44772 20 5 19.5523 5 19V12C5 11.4477 5.44772 11 6 11H7Z" fill="currentColor"></path></svg>';
            const thumbsDownSvg = '<svg aria-label="Bad Response" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-md-heavy thumbs-down" data-chat-id="' + escapeHtml(chatId) + '" title="Bad Response"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.8727 21.4961C11.6725 21.8466 11.2811 22.0423 10.8805 21.9922L10.4267 21.9355C7.95958 21.6271 6.36855 19.1665 7.09975 16.7901L7.65054 15H6.93226C4.29476 15 2.37923 12.4921 3.0732 9.94753L4.43684 4.94753C4.91145 3.20728 6.49209 2 8.29589 2H18.0045C19.6614 2 21.0045 3.34315 21.0045 5V12C21.0045 13.6569 19.6614 15 18.0045 15H16.0045C15.745 15 15.5054 15.1391 15.3766 15.3644L11.8727 21.4961ZM14.0045 4H8.29589C7.39399 4 6.60367 4.60364 6.36637 5.47376L5.00273 10.4738C4.65574 11.746 5.61351 13 6.93226 13H9.00451C9.32185 13 9.62036 13.1506 9.8089 13.4059C9.99743 13.6612 10.0536 13.9908 9.96028 14.2941L9.01131 17.3782C8.6661 18.5002 9.35608 19.6596 10.4726 19.9153L13.6401 14.3721C13.9523 13.8258 14.4376 13.4141 15.0045 13.1902V5C15.0045 4.44772 14.5568 4 14.0045 4ZM17.0045 13V5C17.0045 4.64937 16.9444 4.31278 16.8338 4H18.0045C18.5568 4 19.0045 4.44772 19.0045 5V12C19.0045 12.5523 18.5568 13 18.0045 13H17.0045Z" fill="currentColor"></path></svg>';
            footerHtml += `<div class="rating">${thumbsUpSvg}${thumbsDownSvg}</div>`;
        }
        if (footerHtml) footerHtml = `<div class="bot-message-footer">${footerHtml}</div>`;
        // --- End Prepare Footer ---

        // Pre-format the final HTML content
        const finalFormattedHtml = formatMessageContent(message);

        // Append the message container div (initially empty)
        $container.append($msgDiv);
        try { $container.scrollTop($container[0].scrollHeight); } catch (e) { /* ignore scroll error */ }

        // Typing effect logic
        let i = 0;
        const typingSpeed = 15; // ms per character
        let currentTypedText = '';
        const $targetDiv = $('#' + uniqueId); // Re-select by unique ID

        if (!$targetDiv.length) {
            console.error("AwesomeBot: Target div for typing not found!", uniqueId);
            return;
        }

        function typeCharacter() {
            if (i < message.length) {
                currentTypedText += message.charAt(i);
                $targetDiv.text(currentTypedText); // Update with plain text
                i++;
                try { $container.scrollTop($container[0].scrollHeight); } catch (e) { /* ignore */ }
                setTimeout(typeCharacter, typingSpeed);
            } else {
                // Typing complete: Replace plain text with fully formatted HTML + footer
                $targetDiv.html(finalFormattedHtml + footerHtml);
                try { $container.scrollTop($container[0].scrollHeight); } catch (e) { /* ignore */ }

                // Add this bot response to session history AFTER displaying
                addTurnToHistory('model', message); // Add the raw bot message text
            }
        }
        typeCharacter(); // Start typing effect
    }

    /**
     * Sends the user message and conversation history via AJAX.
     * @param {string} query The user's input query.
     * @param {string} context 'widget' or 'console'.
     */
    function sendMessage(query, context) {
        const isWidget = (context === 'widget');
        const $messages = isWidget ? $('#awesomebot-messages') : $('#console-messages');
        const $input = isWidget ? $('#awesomebot-input') : $('#console-input');
        const $submit = isWidget ? $('#awesomebot-submit') : $('#console-submit');
        const action = isWidget ? 'awesomebot_request' : 'awesomebot_console_request';
        const nonce = isWidget ? widget_nonce : console_nonce;
        const thinkingId = 'awesomebot-thinking-' + Date.now();

        const currentQuery = query.trim();
        if (currentQuery === '') return; // Don't send empty messages

        // Configuration check
        if (!ajax_url || !nonce) {
            console.error('AwesomeBot Error: AJAX URL or Nonce missing. Cannot send message.');
            // Display error visually
            $('<div class="bot-message error-message">Error: Configuration problem. Cannot send message.</div>').appendTo($messages);
            try { $messages.scrollTop($messages[0].scrollHeight); } catch (e) {}
            return;
        }

        // Append user message visually
        $messages.append('<div class="user-message">' + escapeHtml(currentQuery) + '</div>');
        $input.val('').trigger('input'); // Clear input and trigger auto-resize
        try { $messages.scrollTop($messages[0].scrollHeight); } catch (e) {}

        // Add user message to history *before* sending AJAX
        addTurnToHistory('user', currentQuery);

        // Show thinking indicator and disable input
        $messages.find('.thinking-indicator').remove(); // Remove previous indicators
        $messages.append('<div class="bot-message thinking-indicator" id="' + thinkingId + '"><span>.</span><span>.</span><span>.</span></div>');
        try { $messages.scrollTop($messages[0].scrollHeight); } catch (e) {}
        $submit.prop('disabled', true);
        $input.prop('disabled', true); // Disable textarea too

        console.log(`AwesomeBot (${context}): Sending query...`);

        // Prepare AJAX data, including conversation history
        const ajaxData = {
            action: action,
            nonce: nonce,
            query: currentQuery,
            history: currentSessionHistory // Send the current history
        };

        $.ajax({
            url: ajax_url,
            method: 'POST',
            data: ajaxData,
            dataType: 'json', // Expect JSON response
            success: function(r) {
                $('#' + thinkingId).remove(); // Remove thinking indicator
                if (r && r.success && r.data && r.data.response) {
                    // Display bot response using typeMessage
                    typeMessage($messages, r.data.response, r.data.chat_id, r.data.is_rag || false);
                } else {
                    // Handle backend errors reported in success:false response
                    const errorMsg = 'Error: ' + (r && r.data && r.data.message ? r.data.message : 'Unknown server error.');
                    console.error('AwesomeBot Server Error:', errorMsg);
                    typeMessage($messages, errorMsg, null, false);
                    addTurnToHistory('model', errorMsg); // Add error as bot turn
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('#' + thinkingId).remove(); // Remove thinking indicator
                console.error('AwesomeBot AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
                const errorMsg = 'Sorry, I encountered a communication problem. Please try again.';
                typeMessage($messages, errorMsg, null, false);
                addTurnToHistory('model', errorMsg); // Add error as bot turn
            },
            complete: function() {
                $submit.prop('disabled', false); // Re-enable submit button
                $input.prop('disabled', false); // Re-enable textarea
                // Ensure thinking indicator is removed in case of edge cases
                setTimeout(() => $('#' + thinkingId).remove(), 100);
            }
        });
    }


    // --- Widget UI Event Handlers ---
    $(document).on('click', '#awesomebot-icon', function() {
        $('.awesomebot-wrapper').addClass('active');
        setTimeout(() => {
            const msgContainer = $('#awesomebot-messages');
            if (msgContainer.length) { msgContainer.scrollTop(msgContainer[0].scrollHeight); }
            $('#awesomebot-input').focus();
        }, 50); // Small delay for animation
    });

    $(document).on('click', '.awesomebot-close-button', function() {
        $('.awesomebot-wrapper').removeClass('active');
    });

    $(document).on('click', '.awesomebot-reset-button', function() {
        $('#awesomebot-messages').empty(); // Clear visual messages
        clearSessionHistory(); // Clear stored session history
        $('#awesomebot-input').val('').trigger('input'); // Clear input & resize
        console.log("AwesomeBot: Conversation reset.");
    });

    // --- Input Event Handlers (Widget & Console) ---
    $(document).on('click', '#awesomebot-submit', function(e) {
        e.preventDefault();
        sendMessage($('#awesomebot-input').val(), 'widget');
    });
    $(document).on('keydown', '#awesomebot-input', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage($('#awesomebot-input').val(), 'widget');
        }
    });
    // Auto-resize textarea
    $(document).on('input', '#awesomebot-input, #console-input', function() {
        this.style.height = 'auto'; // Reset height
        const mh = parseInt($(this).css('max-height')) || ($(this).is('#awesomebot-input') ? 100 : 150); // Get max-height from CSS
        this.style.height = Math.min(this.scrollHeight, mh) + 'px'; // Set new height up to max
    });

    $(document).on('click', '#console-submit', function(e) {
        e.preventDefault();
        sendMessage($('#console-input').val(), 'console');
    });
    $(document).on('keydown', '#console-input', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage($('#console-input').val(), 'console');
        }
    });


    // --- Rating Interaction ---
    $(document).on('click', '.rating svg', function() {
        const $this = $(this);
        const chatId = $this.data('chat-id');
        const rating = $this.hasClass('thumbs-up') ? 'thumbs_up' : 'thumbs_down';
        const $ratingDiv = $this.closest('.rating'); // Use closest to find parent rating div

        // Prevent multiple clicks or rating if ID is invalid or already rated
        if ($ratingDiv.hasClass('rated') || chatId === null || typeof chatId === 'undefined') {
            return;
        }
        if (!ajax_url || !console_nonce) {
            console.error('AwesomeBot Rating Error: Configuration missing.');
            // Optionally provide user feedback, e.g., alert('Could not record rating...');
            return;
        }

        console.log('AwesomeBot: Sending rating:', rating, 'for chatId:', chatId);
        $ratingDiv.addClass('processing rated'); // Add rated class immediately for visual feedback

        $.ajax({
            url: ajax_url,
            method: 'POST',
            data: {
                action: 'awesomebot_rate_response',
                nonce: console_nonce, // Use console_nonce for rating/transcript
                chat_id: chatId,
                rating: rating
            },
            dataType: 'json',
            success: function(r) {
                if (r && r.success) {
                    $this.addClass('rated'); // Highlight the clicked icon
                    $ratingDiv.find('svg').not($this).removeClass('rated').css('opacity', '0.5'); // Dim the other icon
                    console.log('AwesomeBot: Rating recorded successfully.');
                } else {
                    console.error('AwesomeBot Rating Error (Server):', r?.data?.message || 'Unknown error');
                    $ratingDiv.removeClass('rated'); // Remove visual indication if save failed
                    // alert('Failed to record rating: ' + escapeHtml(r?.data?.message || 'Server error'));
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('AwesomeBot Rating AJAX Error:', textStatus, errorThrown);
                $ratingDiv.removeClass('rated'); // Remove visual indication on AJAX error
                // alert('Failed to record rating due to a communication error.');
            },
            complete: function() {
                $ratingDiv.removeClass('processing'); // Remove processing indicator
            }
        });
    });

    // --- Transcript Sending ---

    /**
     * Gathers transcript text and sends it via AJAX.
     * @param {jQuery} $messagesContainer jQuery object for the messages div.
     * @param {jQuery} $button jQuery object for the clicked transcript button.
     */
    function sendTranscript($messagesContainer, $button) {
        // Extract text, trying to exclude footer elements more reliably
        const transcript = $messagesContainer.children().map(function() {
            const $m = $(this);
            let prefix = '';
            if ($m.hasClass('user-message')) {
                prefix = 'User: ';
            } else if ($m.hasClass('bot-message')) {
                prefix = 'AwesomeBot: ';
            } else {
                return null; // Skip non-message elements
            }
            // Clone, remove footer/rating/indicator, then get text
            let messageText = $m.clone()
                .find('.bot-message-footer, .rating, .thinking-indicator').remove().end()
                .text();
            return prefix + messageText.trim();
        }).get().filter(line => line !== null).join('\n\n'); // Filter out nulls before joining

        if (!transcript) {
            alert('No conversation history to send.'); // Provide user feedback
            return;
        }

        if (!support_email || !ajax_url || !console_nonce) {
            alert('Cannot send transcript: Support email configuration is missing or invalid.');
            console.error('AwesomeBot Transcript Error: Config missing.');
            return;
        }

        const originalButtonContent = $button.html(); // Store original content (may include SVG)
        $button.prop('disabled', true).text('Sending...'); // Simple text indicator

        console.log('AwesomeBot: Sending transcript...');

        $.ajax({
            url: ajax_url,
            method: 'POST',
            data: {
                action: 'awesomebot_send_transcript',
                nonce: console_nonce, // Use console_nonce for rating/transcript
                transcript: transcript,
                email: support_email // Send to configured support email
            },
            dataType: 'json',
            success: function(r) {
                if (r && r.success) {
                    alert('Transcript sent successfully!');
                    console.log('AwesomeBot: Transcript sent.');
                } else {
                    alert('Failed to send transcript: ' + escapeHtml(r?.data?.message || 'Unknown error'));
                    console.error('AwesomeBot Transcript Error (Server):', r?.data?.message);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('Failed to send transcript due to a server communication error.');
                console.error('AwesomeBot Transcript AJAX Error:', textStatus, errorThrown);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalButtonContent); // Restore original button content
            }
        });
    }
    // Bind transcript buttons
    $(document).on('click', '#console-transcript', function() { sendTranscript($('#console-messages'), $(this)); });
    $(document).on('click', '#awesomebot-send-transcript-widget', function() { sendTranscript($('#awesomebot-messages'), $(this)); });

}); // End jQuery document ready