/**
 * AwesomeBot Admin Area JavaScript
 *
 * Handles admin UI interactions: tab navigation, previews, validation, modals,
 * AJAX actions (export, tests), date pickers, TinyMCE bindings, shortcode copy.
 *
 * @since 1.0.0
 * @version 1.1.1 // Corrected file upload button logic
 * @package AwesomeBot
 */

jQuery(document).ready(function($) {

    // --- Configuration & Initialization ---
    const ajax_url = window.awesomebot_admin_data?.ajax_url;
    const admin_nonce = window.awesomebot_admin_data?.nonce; // Nonce for general admin actions
    const text = window.awesomebot_admin_data?.text || {}; // Localized text strings

    // Check if essential config data is missing
    if (!ajax_url || !admin_nonce) {
        console.error('AwesomeBot Admin Error: Missing localized data (ajax_url or nonce). Some features might fail.');
    }

    // --- Helper Functions ---

    /**
     * Safely checks if a TinyMCE editor has non-empty content.
     * Falls back to checking the underlying textarea value.
     * @param {string} editorId The HTML ID of the TinyMCE editor instance.
     * @returns {boolean} True if content is non-empty, false otherwise.
     */
    function isEditorContentNonEmpty(editorId) {
        try {
            if (typeof tinymce !== 'undefined' && tinymce.get(editorId)) {
                const editor = tinymce.get(editorId);
                if (editor && editor.initialized) {
                    const content = editor.getContent({ format: 'text' }) || '';
                    return content.trim().length > 0;
                } else {
                    return !!$('#' + editorId).val()?.trim();
                }
            } else {
                return !!$('#' + editorId).val()?.trim();
            }
        } catch (e) {
            console.error("AwesomeBot Admin: Error checking editor content for #" + editorId + ":", e);
            return !!$('#' + editorId).val()?.trim();
        }
    }

    /** Validates the Add Q&A form fields. */
    function validateQAAddForm() {
        try {
            const questionIsNonEmpty = !!$('#qa_question').val()?.trim();
            const answerIsNonEmpty = isEditorContentNonEmpty('new_qa_answer');
            $('#add-qa-submit').prop('disabled', !(questionIsNonEmpty && answerIsNonEmpty));
        } catch (e) {
            console.error("AwesomeBot Admin: Error during Add QA validation:", e);
            $('#add-qa-submit').prop('disabled', true);
        }
    }

    /** Validates the Add Link form field. */
    function validateLinkAddForm() {
        const url = $('#link_content').val()?.trim();
        let isValid = false;
        if (url) {
            if (url.startsWith('http://') || url.startsWith('https://')) {
                try { new URL(url); isValid = true; } catch (_) { isValid = false; }
            }
        }
        // Also check if the button was disabled by PHP (Action Scheduler missing)
        const submitButton = $('#add-link-submit');
        if (submitButton.attr('disabled') === 'disabled' && !isValid) {
             // If PHP disabled it, leave it disabled unless the URL becomes valid
             // This case might not be necessary if PHP only disables based on AS
        } else if (submitButton.attr('disabled') === 'disabled' && isValid) {
             // If PHP disabled it BUT URL is now valid, this shouldn't happen if PHP only checks AS.
             // Let's assume PHP only disables based on AS missing.
             // So, if PHP didn't disable it, control is based purely on validity.
             submitButton.prop('disabled', !isValid);
        } else {
            // If PHP didn't disable it initially, control based on validity.
            submitButton.prop('disabled', !isValid);
        }
    }

    /**
     * Validates the File Upload form field.
     * Enables/disables the submit button ONLY if it wasn't permanently
     * disabled by PHP (due to missing Action Scheduler).
     */
    function validateFileUploadForm() {
        const fileInput = document.getElementById('file_upload');
        const submitButton = $('#file-upload-submit');
        const $fileInput = $('#file_upload'); // jQuery object for checking attributes

        // Check if PHP initially disabled the file input itself.
        // If the file input is disabled, it implies Action Scheduler is missing,
        // so the submit button should also remain disabled permanently.
        const isDisabledByPHP = $fileInput.is('[disabled]');

        if (isDisabledByPHP) {
            // Ensure submit button is also disabled if PHP disabled the input.
            submitButton.prop('disabled', true);
            return;
        }

        // If not disabled by PHP, control the button based on file selection.
        const isFileSelected = !!(fileInput && fileInput.files && fileInput.files.length > 0);
        submitButton.prop('disabled', !isFileSelected); // Disable if NO file is selected
    }


    /** Copies provided text to the clipboard. */
    function copyToClipboard(textToCopy, successMsg = text.copied_success || 'Copied!') {
        if (!textToCopy) return;
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy).then(
                () => alert(successMsg),
                () => fallbackCopy(textToCopy, successMsg)
            );
        } else {
            fallbackCopy(textToCopy, successMsg);
        }
    }

    /** Fallback copy method using execCommand. */
    function fallbackCopy(textToCopy, successMsg) {
        const textArea = document.createElement("textarea");
        textArea.value = textToCopy;
        textArea.style.position = "fixed"; textArea.style.top = "-9999px"; textArea.style.left = "-9999px";
        textArea.setAttribute("readonly", "");
        document.body.appendChild(textArea);
        textArea.select();
        try {
            document.execCommand('copy') ? alert(successMsg) : alert(text.copy_failed || 'Copy failed.');
        } catch (err) {
            console.error("Fallback copy failed:", err);
            alert(text.copy_failed || 'Copy failed.');
        }
        document.body.removeChild(textArea);
    }

    /** Activates the appropriate admin tab based on URL hash or defaults. */
    function activateInitialTab() {
        let activeTabHash = window.location.hash || '#general-tab';
        if (!$('.awesomebot-admin .nav-tab-wrapper a.nav-tab[href="' + activeTabHash + '"]').length) {
            activeTabHash = '#general-tab';
        }
        $('.awesomebot-admin .nav-tab-wrapper a.nav-tab[href="' + activeTabHash + '"]').trigger('click');
    }

    /** Runs API connection tests via AJAX. */
    function runConnectionTest(service) {
        const $button = $('.test-connection[data-service="' + service + '"]');
        const $statusSpan = $('#' + service + '-status');
        if (!service || !$button.length || !$statusSpan.length || !ajax_url || !admin_nonce) {
            console.error('Missing data for connection test.', service); return;
        }
        let action = '';
        if (service === 'gemini') action = 'awesomebot_test_gemini';
        else if (service === 'pinecone') action = 'awesomebot_test_pinecone';
        else return;

        $statusSpan.text(text.test_connecting || 'Testing...').removeClass('connected disconnected').addClass('testing');
        $button.prop('disabled', true);

        $.ajax({
            url: ajax_url, method: 'POST',
            data: { action: action, nonce: admin_nonce },
            dataType: 'json',
            success: function(r) {
                if (r.success) {
                    $statusSpan.text(text.test_connected || 'Connected').removeClass('testing disconnected').addClass('connected');
                } else {
                    $statusSpan.text(text.test_disconnected || 'Disconnected').removeClass('testing connected').addClass('disconnected');
                    alert((text.test_failed || 'Test Failed: ') + (r.data?.message || text.error_unknown || 'Unknown error'));
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('Connection test AJAX error:', textStatus, errorThrown);
                $statusSpan.text(text.test_error || 'Error').removeClass('testing connected').addClass('disconnected');
                alert(text.test_error_comm || 'Test failed (server/network error). Check console/logs.');
            },
            complete: function() { $button.prop('disabled', false); }
        });
    }

    // --- Event Binding & Initialization ---

    // Sources Page: Bind input validation listeners
    $('#qa_question').on('input keyup', validateQAAddForm);
    $('#link_content').on('input keyup', validateLinkAddForm);
    $('#file_upload').on('change', validateFileUploadForm); // Bind file input change
    // Run initial validation on page load
    validateQAAddForm();
    validateLinkAddForm();
    validateFileUploadForm(); // Ensure initial state is set correctly

    // Sources/History Page: Bind TinyMCE validation/content setting (delayed)
    function bindEditorValidation(editorId, validationFunc) {
        setTimeout(function() { // Delay to ensure editor might be ready
            if (typeof tinymce !== 'undefined') {
                const editor = tinymce.get(editorId);
                if (editor) {
                    const bindEvents = function() {
                        this.off('keyup input change SetContent nodeChange', validationFunc); // Remove previous bindings first
                        this.on('keyup input change SetContent nodeChange', validationFunc);
                        validationFunc(); // Run validation immediately after binding
                    };
                    if (editor.initialized) {
                        bindEvents.call(editor);
                    } else {
                        editor.once('init', function() { bindEvents.call(this); }); // Use once to avoid multiple bindings on re-init
                    }
                } else { $('#' + editorId).on('input keyup change', validationFunc); validationFunc(); } // Fallback
            } else { $('#' + editorId).on('input keyup change', validationFunc); validationFunc(); } // Fallback
        }, 800); // Adjust delay if needed
    }
    // Apply validation binding if the editors exist on the page
    if ($('#new_qa_answer').length) { bindEditorValidation('new_qa_answer', validateQAAddForm); }

    // Helper to safely set TinyMCE content (used in modals)
    function setEditorContent(editorId, content) {
        try {
            const editor = (typeof tinymce !== 'undefined') ? tinymce.get(editorId) : null;
            const safeContent = String(content || '');
            if (editor) {
                if (editor.initialized) {
                    editor.setContent(safeContent);
                } else {
                    // Use a slight delay and check again, or bind to init
                    editor.once('init', function() { this.setContent(safeContent); });
                    // Also set textarea value as a fallback
                    $('#' + editorId).val(safeContent);
                }
            } else {
                $('#' + editorId).val(safeContent); // Fallback if no editor
            }
        } catch (e) {
            console.error("Error setting editor content for #" + editorId + ":", e);
            $('#' + editorId).val(String(content || '')); // Fallback
        }
    }

    // All Pages: Tab Navigation Click Handler
    $('.awesomebot-admin .nav-tab-wrapper').on('click', 'a.nav-tab', function(e) {
        const $this = $(this);
        const targetId = $this.attr('href');
        if (targetId && targetId.startsWith('#')) {
            e.preventDefault();
            const $targetContent = $(targetId);
            if ($targetContent.length) {
                $('.nav-tab').removeClass('nav-tab-active');
                $this.addClass('nav-tab-active');
                $('.tab-content').hide();
                $targetContent.show();
                try { history.replaceState(null, '', targetId); } catch (err) {}
            }
        }
    });
    // Activate initial tab after a short delay
    setTimeout(activateInitialTab, 100);

    // Settings Page: Theme and Icon Preview Updates
    $('#theme').change(function() {
        const theme = $(this).val() || 'default';
        $('#theme-preview, #icon-preview').removeClass((i, c) => (c.match(/(^|\s)theme-\S+/g) || []).join(' ')).addClass('theme-' + theme);
    });
    $('#icon').change(function() {
        const icon = $(this).val() || 'default';
        const $preview = $('#icon-preview');
        if (!ajax_url || !admin_nonce) return;
        $.ajax({
            url: ajax_url, method: 'POST', dataType: 'json',
            data: { action: 'awesomebot_get_icon', nonce: admin_nonce, icon: icon },
            success: function(r) { $preview.html(r?.success && r.data?.svg ? r.data.svg : ''); },
            error: function() { console.error("Icon preview AJAX error."); $preview.html(''); }
        });
    });
    $('#console_theme').change(function() {
        const theme = $(this).val() || 'default';
        $('#console-preview').removeClass((i, c) => (c.match(/(^|\s)console-theme-\S+/g) || []).join(' ')).addClass('console-theme-' + theme);
    });

    // History/Reports Page: Date Picker Initialization
    if ($('.date-picker').length && typeof flatpickr === 'function') {
        flatpickr('.date-picker', { dateFormat: 'Y-m-d', altInput: true, altFormat: "M j, Y" });
    }

    // --- Modal Handlers ---
    // History Page: Open/Populate Revise Answer Modal
    $(document).on('click', '.revise-answer', function() {
        const index = $(this).data('index');
        const question = $(this).data('question');
        const answer = $(this).data('answer');
        if (typeof index === 'undefined' || typeof question === 'undefined' || typeof answer === 'undefined') {
            alert(text.error_modal_data || 'Error: Missing data for modal.'); return;
        }
        $('#revise-index').val(index);
        $('#revise-question').text(question || 'N/A');
        setEditorContent('revised-answer', answer);
        $('#revise-modal').fadeIn();
    });

    // Sources Page: Open/Populate Edit Source Modal
    $(document).on('click', '.edit-source', function() {
        const id = $(this).data('id');
        const type = $(this).data('type');
        const content = $(this).data('content');
        const question = $(this).data('question');
        const answer = $(this).data('answer');
        const activeTab = $(this).closest('.tab-content').attr('id') || 'qa-tab';

        if (typeof id === 'undefined' || typeof type === 'undefined') {
            alert(text.error_modal_data || 'Error: Missing data for modal.'); return;
        }

        // Populate hidden fields
        $('#edit-source-id').val(id);
        $('#edit-source-type').val(type);
        $('#edit-active-tab').val(activeTab);

        // Get modal field elements
        const $qaFields = $('#edit-qa-fields');
        const $contentField = $('#edit-content-field');
        const $qaQ = $('#edit-qa-question');
        const $qaAEditorId = 'edit_qa_answer_modal';
        const $contentInput = $('#edit-source-content');
        const $contentLabel = $('#edit-content-type-label');
        const $contentDesc = $('#edit-content-desc');
        const $saveButton = $('#edit-modal .button-primary');

        // Hide all conditional fields initially & reset attributes
        $qaFields.hide(); $contentField.hide();
        $qaQ.prop('required', false);
        $contentInput.prop('required', false).prop('readonly', false).attr('type', 'text');
        $saveButton.prop('disabled', false); // Re-enable save button initially

        // Configure fields based on source type
        if (type === 'qa') {
            $qaQ.val(question || '').prop('required', true);
            setEditorContent($qaAEditorId, answer);
            $qaFields.show();
        } else if (type === 'link') {
            $contentLabel.text(text.label_link_url || 'Link URL');
            $contentInput.val(content || '').attr('type', 'url').prop('required', true);
            $contentDesc.text(text.desc_edit_link || 'Edit the source URL. This will trigger reprocessing.');
            $contentField.show();
        } else if (type === 'file' || type === 'wp_content') {
            $contentLabel.text(type === 'file' ? (text.label_filename || 'Filename') : (text.label_post_title || 'Post/Page Title'));
            $contentInput.val(content || 'N/A').prop('readonly', true);
            $contentDesc.text(type === 'file' ? (text.desc_edit_file || 'File content cannot be edited.') : (text.desc_edit_wp || 'Edit via standard WordPress post editor.'));
            $contentField.show();
            $saveButton.prop('disabled', true); // Disable save for non-editable types
        }
        $('#edit-modal').fadeIn();
    });

    // General Modal Close Handlers
    $(document).on('click', '#cancel-revise-modal, #close-revise-modal', function() { $('#revise-modal').fadeOut(); });
    $(document).on('click', '#cancel-edit-modal, #close-edit-modal', function() { $('#edit-modal').fadeOut(); });
    $(document).on('click', '.awesomebot-modal', function(e) { if ($(e.target).is('.awesomebot-modal')) $(this).fadeOut(); });

    // --- Admin AJAX Actions ---
    // History Page: Export Chat History
    $('#export-chat-history').click(function(e) {
        e.preventDefault();
        const $button = $(this);
        if (!ajax_url || !admin_nonce) { alert(text.error_config || 'Config error.'); return; }

        const startDate = $button.data('start-date') || $('#start_date').val();
        const endDate = $button.data('end-date') || $('#end_date').val();

        $button.text(text.exporting || 'Exporting...').prop('disabled', true);

        $.ajax({
            url: ajax_url, method: 'POST', dataType: 'json',
            data: { action: 'awesomebot_export_chat_history', nonce: admin_nonce, start_date: startDate, end_date: endDate },
            success: function(r) {
                if (r.success && r.data.csv && r.data.filename) {
                    try {
                        const byteCharacters = atob(r.data.csv);
                        const byteNumbers = new Array(byteCharacters.length);
                        for (let i = 0; i < byteCharacters.length; i++) { byteNumbers[i] = byteCharacters.charCodeAt(i); }
                        const byteArray = new Uint8Array(byteNumbers);
                        const blob = new Blob([byteArray], { type: 'text/csv;charset=utf-8;' });

                        const link = document.createElement("a");
                        if (link.download !== undefined) {
                            const url = URL.createObjectURL(blob);
                            link.setAttribute("href", url);
                            link.setAttribute("download", r.data.filename);
                            link.style.visibility = 'hidden';
                            document.body.appendChild(link); link.click(); document.body.removeChild(link);
                            URL.revokeObjectURL(url);
                        } else { alert(text.error_download_support || 'Direct download not supported by browser.'); }
                    } catch (e) {
                        console.error("Error decoding/downloading CSV:", e);
                        alert(text.export_failed_process || 'Export failed: Could not process CSV data.');
                    }
                } else {
                    alert((text.export_failed || 'Export failed:') + ' ' + (r.data?.message || text.error_unknown || 'Unknown server error'));
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('Export AJAX error:', textStatus, errorThrown);
                alert(text.export_failed_comm || 'Export failed due to a server communication error.');
            },
            complete: function() { $button.text(text.export_button || 'Export CSV').prop('disabled', false); }
        });
    });

    // Settings Page: Test Connection Buttons
    $('.test-connection').on('click', function(e) {
        e.preventDefault();
        runConnectionTest($(this).data('service'));
    });

    // Dismissible Notices Handler
    $(document).on('click', '.notice.is-dismissible .notice-dismiss', function () {
        $(this).closest('.notice').fadeOut('fast', function() { $(this).remove(); });
    });

    // Copy Shortcode Buttons
    $('.copy-shortcode').click(function(e) {
        e.preventDefault();
        const targetId = $(this).data('target');
        const $input = $(targetId);
        if ($input.length) { copyToClipboard($input.val(), text.copied_success || 'Copied!'); }
    });

}); // End jQuery document ready