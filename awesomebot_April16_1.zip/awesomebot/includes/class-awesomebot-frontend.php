<?php
/**
 * Handles the frontend display and assets for the AwesomeBot plugin.
 *
 * Registers shortcodes ([awesomebot], [awesomebot-console]), enqueues assets conditionally,
 * and provides helper methods like retrieving icon SVG markup.
 *
 * @package AwesomeBot
 * @since   1.0.0
 * @version 1.1.0
 */

declare(strict_types=1);

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class AwesomeBot_Frontend
 *
 * Manages frontend shortcodes and assets.
 */
class AwesomeBot_Frontend {

    /**
     * Constructor.
     * Registers shortcodes and hooks the script/style enqueueing function.
     *
     * @since 1.0.0
     */
    public function __construct() {
        // Register shortcodes for frontend display.
        add_shortcode('awesomebot', [$this, 'render_chatbot']);
        add_shortcode('awesomebot-console', [$this, 'render_console']);

        // Hook function to enqueue frontend assets.
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    /**
     * Enqueues frontend scripts and styles conditionally.
     *
     * Assets are loaded only on non-admin pages where either the [awesomebot]
     * or [awesomebot-console] shortcode is detected in the main post content,
     * or if forced via the 'awesomebot_force_load_frontend_assets' filter.
     *
     * @since 1.0.0
     * @global WP_Post|null $post The global post object.
     * @return void
     */
    public function enqueue_scripts(): void {
        // Don't load assets in the admin area or during AJAX requests.
        if (is_admin() || wp_doing_ajax()) {
            return;
        }

        global $post;
        $load_assets = false;

        // Check post content for shortcodes only if $post is a valid WP_Post object.
        if (is_a($post, 'WP_Post') && property_exists($post, 'post_content')) {
            if (has_shortcode($post->post_content, 'awesomebot') || has_shortcode($post->post_content, 'awesomebot-console')) {
                $load_assets = true;
            }
        }

        /**
         * Filter whether to force loading frontend assets.
         * Useful if shortcodes are used in widgets, theme templates, or other non-post_content areas.
         *
         * @since 1.0.0
         * @param bool $load_assets Whether to load assets. Default based on shortcode detection.
         */
        $load_assets = (bool) apply_filters('awesomebot_force_load_frontend_assets', $load_assets);

        // Enqueue if needed.
        if ($load_assets) {
            // --- Enqueue Frontend CSS ---
            wp_enqueue_style(
                'awesomebot-frontend-css', // Handle
                AWESOMEBOT_URL . 'assets/css/frontend.css', // Source URL
                [], // Dependencies
                AWESOMEBOT_VERSION // Version
            );

            // --- Enqueue Frontend JS ---
            wp_enqueue_script(
                'awesomebot-frontend-js', // Handle
                AWESOMEBOT_URL . 'assets/js/frontend.js', // Source URL
                ['jquery'], // Dependencies (relies on jQuery)
                AWESOMEBOT_VERSION, // Version
                true // Load in footer
            );

            // --- Pass PHP data to JavaScript ---
            $support_email_raw = get_option('awesomebot_support_email', '');
            $valid_support_email = is_email($support_email_raw) ? $support_email_raw : ''; // Only pass if valid

            wp_localize_script(
                'awesomebot-frontend-js', // Script handle to attach data to
                'awesomebot_data',       // JavaScript object name
                [
                    'ajax_url'      => admin_url('admin-ajax.php'),
                    'nonce'         => wp_create_nonce('awesomebot_nonce'), // Nonce for main widget requests
                    'console_nonce' => wp_create_nonce('awesomebot_console_nonce'), // Nonce for console/rating/transcript
                    'support_email' => $valid_support_email, // Pass validated email for transcript feature
                ]
            );
        }
    }

    /**
     * Renders the floating chatbot widget HTML.
     * Callback for the [awesomebot] shortcode.
     * Ensures assets are loaded before rendering.
     *
     * @since 1.0.0
     * @since 1.1.0 Added stricter asset loading checks.
     * @return string The HTML output for the chatbot widget. Returns empty string if assets cannot be loaded.
     */
    public function render_chatbot(): string {
        // Ensure assets are enqueued if shortcode renders unexpectedly early or outside main content.
        if (!wp_script_is('awesomebot-frontend-js', 'enqueued') && !is_admin()) {
            // Attempt to enqueue manually (might be too late depending on hook order).
            $this->enqueue_scripts();
            // Check again - if still not loaded, log error and return empty to avoid broken UI.
            if (!wp_script_is('awesomebot-frontend-js', 'enqueued')) {
                if (class_exists('AwesomeBot_Logs')) {
                     AwesomeBot_Logs::log('Frontend assets could not be enqueued/verified for [awesomebot] shortcode render.', 'error');
                }
                // Optionally return a placeholder comment instead of empty string for debugging.
                // return '';
                return '';
            }
        }

        // Get display settings.
        $settings = get_option('awesomebot_settings', ['theme' => 'default', 'icon' => 'default']);
        $theme_class = 'theme-' . esc_attr($settings['theme'] ?? 'default');
        $icon_setting = esc_attr($settings['icon'] ?? 'default');
        $support_email_raw = get_option('awesomebot_support_email', '');
        $can_send_transcript = is_email($support_email_raw); // Check if transcript feature can be enabled

        // Start output buffering.
        ob_start();
        ?>
        <div class="awesomebot-wrapper <?php echo esc_attr($theme_class); ?>">
            <div class="awesomebot-chat-container">
                <div class="awesomebot-chat-inner-container">
                    <button type="button" class="awesomebot-close-button" aria-label="<?php esc_attr_e('Close chat', 'awesomebot'); ?>">
                        <svg aria-hidden="true" focusable="false" viewBox="0 0 384 512"><path fill="currentColor" d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"></path></svg>
                    </button>
                    <div class="awesomebot-chat-header">
                        <div class="awesomebot-chat-header-content">
                            <button type="button" title="<?php esc_attr_e('Reset conversation', 'awesomebot'); ?>" class="awesomebot-reset-button awesomebot-header-button" aria-label="<?php esc_attr_e('Reset conversation', 'awesomebot'); ?>">
                                <svg aria-hidden="true" focusable="false" viewBox="0 0 512 512" width="18" height="18"><path fill="currentColor" d="M105.1 202.6c7.7-21.8 20.2-42.3 37.8-59.8c62.5-62.5 163.8-62.5 226.3 0L386.3 160H336c-17.7 0-32 14.3-32 32s14.3 32 32 32H463.5c0 0 0 0 0 0h.4c17.7 0 32-14.3 32-32V64c0-17.7-14.3-32-32-32s-32 14.3-32 32v51.2L414.4 97.6c-87.5-87.5-229.3-87.5-316.8 0C73.2 122 55.6 150.7 44.8 181.4c-5.9 16.7 2.9 34.9 19.5 40.8s34.9-2.9 40.8-19.5zM39 289.3c-5 1.5-9.8 4.2-13.7 8.2c-4 4-6.7 8.8-8.1 14c-.3 1.2-.6 2.5-.8 3.8c-.3 1.7-.4 3.4-.4 5.1V448c0 17.7 14.3 32 32 32s32-14.3 32-32V396.9l17.6 17.5 0 0c87.5 87.4 229.3 87.4 316.7 0c24.4-24.4 42.1-53.1 52.9-83.7c5.9-16.7-2.9-34.9-19.5-40.8s-34.9 2.9-40.8 19.5c-7.7 21.8-20.2 42.3-37.8 59.8c-62.5 62.5-163.8 62.5-226.3 0l-.1-.1L125.6 352H176c17.7 0 32-14.3 32-32s-14.3-32-32-32H48.4c-1.6 0-3.2 .1-4.8 .3s-3.1 .5-4.6 1z"></path></svg>
                            </button>
                            <div class="awesomebot-chat-header-title"><?php esc_html_e('AwesomeBot', 'awesomebot'); ?></div>
                             <?php if ($can_send_transcript) : ?>
                                <button type="button" title="<?php esc_attr_e('Send Transcript', 'awesomebot'); ?>" class="awesomebot-transcript-button awesomebot-header-button" id="awesomebot-send-transcript-widget" aria-label="<?php esc_attr_e('Send Transcript', 'awesomebot'); ?>">
                                    <svg aria-hidden="true" viewBox="0 0 512 512" width="18" height="18"><path fill="currentColor" d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"/></svg>
                                </button>
                             <?php endif; ?>
                        </div>
                    </div>
                    <div class="awesomebot-chat-message-container" id="awesomebot-messages">
                        <?php // Messages will be loaded here by JavaScript ?>
                    </div>
                    <div class="awesomebot-chat-input-container">
                        <form class="awesomebot-chat-input-form">
                            <textarea class="awesomebot-chat-input" id="awesomebot-input" placeholder="<?php esc_attr_e('Send a message...', 'awesomebot'); ?>" maxlength="500" rows="1" aria-label="<?php esc_attr_e('Chat message input', 'awesomebot'); ?>"></textarea>
                            <button type="submit" class="awesomebot-chat-btn-send" id="awesomebot-submit" aria-label="<?php esc_attr_e('Send message', 'awesomebot'); ?>">
                                <svg aria-hidden="true" viewBox="0 0 512 512" class="awesomebot-chat-btn-send-icon"><path fill="currentColor" d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"></path></svg>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <button type="button" id="awesomebot-icon" class="awesomebot-icon <?php echo esc_attr($theme_class); ?>" aria-label="<?php esc_attr_e('Open Chat', 'awesomebot'); ?>" role="button" tabindex="0">
            <?php echo wp_kses($this->get_icon_svg($icon_setting), ['svg' => ['width'=>true,'height'=>true,'viewBox'=>true,'fill'=>true,'xmlns'=>true,'stroke'=>true,'stroke-width'=>true,'stroke-linecap'=>true,'stroke-linejoin'=>true,'aria-hidden'=>true,'focusable'=>true,'class'=>true],'path'=>['d'=>true,'fill'=>true,'stroke'=>true,'stroke-width'=>true,'stroke-linecap'=>true,'stroke-linejoin'=>true],'rect'=>['x'=>true,'y'=>true,'width'=>true,'height'=>true,'rx'=>true,'stroke'=>true,'stroke-width'=>true],'circle'=>['cx'=>true,'cy'=>true,'r'=>true,'stroke'=>true,'stroke-width'=>true],'polyline'=>['points'=>true,'stroke'=>true,'stroke-width'=>true],'line'=>['x1'=>true,'y1'=>true,'x2'=>true,'y2'=>true,'stroke'=>true,'stroke-width'=>true]]); ?>
        </button>
        <?php
        // Return buffered content.
        return ob_get_clean();
    }

    /**
     * Renders the embedded chat console HTML.
     * Callback for the [awesomebot-console] shortcode.
     * Ensures assets are loaded before rendering.
     *
     * @since 1.0.0
     * @since 1.1.0 Added stricter asset loading checks and conditional transcript button.
     * @return string The HTML output for the chat console. Returns empty string if assets cannot be loaded.
     */
    public function render_console(): string {
        // Ensure assets are loaded.
        if (!wp_script_is('awesomebot-frontend-js', 'enqueued') && !is_admin()) {
            $this->enqueue_scripts();
            if (!wp_script_is('awesomebot-frontend-js', 'enqueued')) {
                 if (class_exists('AwesomeBot_Logs')) {
                     AwesomeBot_Logs::log('Frontend assets could not be enqueued/verified for [awesomebot-console] shortcode render.', 'error');
                 }
                 // return '';
                 return '';
            }
        }

        // Get console theme setting and check if transcript feature is viable.
        $settings = get_option('awesomebot_settings', ['console_theme' => 'default']);
        $console_theme_class = 'console-theme-' . esc_attr($settings['console_theme'] ?? 'default');
        $support_email_raw = get_option('awesomebot_support_email', '');
        $can_send_transcript = is_email($support_email_raw);

        ob_start();
        ?>
        <div id="awesomebot-console" class="awesomebot-console <?php echo esc_attr($console_theme_class); ?>">
            <div class="console-header">
                <div class="console-title-wrap">
                    <h2><?php esc_html_e('AwesomeBot Console', 'awesomebot'); ?></h2>
                    <p class="console-subtitle"><?php esc_html_e('Ask anything, get instant answers.', 'awesomebot'); ?></p>
                </div>
                <?php // Only show transcript button if a valid support email is configured ?>
                <?php if ($can_send_transcript): ?>
                    <button type="button" id="console-transcript" class="console-button" aria-label="<?php esc_attr_e('Send Transcript to Support', 'awesomebot'); ?>"><?php esc_html_e('Send Transcript', 'awesomebot'); ?></button>
                 <?php endif; ?>
            </div>
            <div id="console-messages" class="console-messages">
                 <?php // Messages loaded by JS ?>
            </div>
            <div class="console-input">
                <textarea id="console-input" placeholder="<?php esc_attr_e('Ask me anything...', 'awesomebot'); ?>" rows="1" aria-label="<?php esc_attr_e('Console message input', 'awesomebot'); ?>"></textarea>
                <button type="button" id="console-submit" class="console-button" aria-label="<?php esc_attr_e('Send message', 'awesomebot'); ?>">
                     <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="18" height="18" fill="currentColor"><path d="M476 3.2L12.5 270.6c-18.1 10.4-15.8 35.6 2.2 43.2L121 358.4l287.3-253.2c5.5-4.9 13.3 2.6 8.6 8.3L176 407v80.5c0 23.6 28.5 32.9 42.5 15.8L282 426l124.6 52.2c14.2 6 30.4-2.9 33-18.2l72-432C515 7.8 493.3-6.8 476 3.2z"/></svg>
                </button>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Retrieves the SVG markup for a given icon key.
     * Used for the floating widget icon and admin preview.
     *
     * @since 1.0.0
     * @since 1.1.0 Added more icons and fallback.
     * @param string $icon The key ('default', 'robot', etc.) of the desired icon.
     * @return string The SVG HTML string, or the default icon SVG if the key is not found.
     */
    public function get_icon_svg(string $icon): string {
        // Define allowed SVG elements and attributes for wp_kses
        $allowed_svg_tags = [
            'svg' => [
                'width' => true, 'height' => true, 'viewBox' => true, 'fill' => true, 'xmlns' => true,
                'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true,
                'aria-hidden' => true, 'focusable' => true, 'class' => true,
            ],
            'path' => ['d' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'fill-rule' => true, 'clip-rule' => true],
            'rect' => ['x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'ry' => true, 'stroke' => true, 'stroke-width' => true, 'fill' => true],
            'circle' => ['cx' => true, 'cy' => true, 'r' => true, 'stroke' => true, 'stroke-width' => true, 'fill' => true],
            'polyline' => ['points' => true, 'stroke' => true, 'stroke-width' => true, 'fill' => true],
            'line' => ['x1' => true, 'y1' => true, 'x2' => true, 'y2' => true, 'stroke' => true, 'stroke-width' => true],
        ];

        // Store SVG markup in an array. Ensure SVGs are safe and properly formatted.
        // Use currentColor for fill/stroke where appropriate for theme compatibility.
        $icons = [
            'default'     => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L14.09 8.26L20 9.27L15.55 13.97L16.91 20L12 16.9L7.09 20L8.45 13.97L4 9.27L9.91 8.26L12 2Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>',
            'robot'       => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="7" y="5" width="10" height="14" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M10 12H14M7 15H17M10 2V5M14 2V5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
            'chat'        => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'user'        => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 12C14.21 12 16 10.21 16 8C16 5.79 14.21 4 12 4C9.79 4 8 5.79 8 8C8 10.21 9.79 12 12 12ZM12 14C9.33 14 4 15.34 4 18V20H20V18C20 15.34 14.67 14 12 14Z" stroke="currentColor" stroke-width="1.5"/></svg>',
            'cog'         => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>',
            'bolt'        => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'star'        => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L14.09 8.26L20 9.27L15.55 13.97L16.91 20L12 16.9L7.09 20L8.45 13.97L4 9.27L9.91 8.26L12 2Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>',
            'heart'       => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" stroke="currentColor" stroke-width="1.5"/></svg>',
            'bell'        => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'book'        => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V6a2 2 0 0 0-2-2H6.5A2.5 2.5 0 0 1 4 6.5V19.5ZM4 19.5A2.5 2.5 0 0 0 6.5 22H18c1.1 0 2-.9 2-2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'camera'      => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="13" r="4" stroke="currentColor" stroke-width="1.5"/></svg>',
            'cloud'       => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" stroke="currentColor" stroke-width="1.5"/></svg>',
            'envelope'    => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" stroke="currentColor" stroke-width="1.5"/><polyline points="22,6 12,13 2,6" stroke="currentColor" stroke-width="1.5"/></svg>',
            'globe'       => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5"/><line x1="2" y1="12" x2="22" y2="12" stroke="currentColor" stroke-width="1.5"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" stroke="currentColor" stroke-width="1.5"/></svg>',
            'lock'        => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" stroke="currentColor" stroke-width="1.5"/><path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="1.5"/></svg>',
            'music'       => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 18V5l12-2v13" stroke="currentColor" stroke-width="1.5"/><circle cx="6" cy="18" r="3" stroke="currentColor" stroke-width="1.5"/><circle cx="18" cy="16" r="3" stroke="currentColor" stroke-width="1.5"/></svg>',
            'paper-plane' => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M22 2L11 13L2 9L22 2ZM11 13V22L16 17L11 13Z" stroke="currentColor" stroke-width="1.5"/></svg>',
            'phone'       => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" stroke="currentColor" stroke-width="1.5"/></svg>',
            'rocket'      => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 12l-1.86 1.86a1.5 1.5 0 0 0-.44 1.06V19.5a1.5 1.5 0 0 0 1.5 1.5h5.58a1.5 1.5 0 0 0 1.06-.44L18 12m-6-6l1.86-1.86a1.5 1.5 0 0 1 1.06-.44H19.5a1.5 1.5 0 0 1 1.5 1.5v5.58a1.5 1.5 0 0 1-.44 1.06L12 18M6 12h12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'shield-alt'  => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-3z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'thumbs-up'   => '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14zM7 21H3v-9h4v9z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        ];

        // Return the requested icon SVG, or default if not found. Sanitize using wp_kses.
        $svg_markup = $icons[$icon] ?? ($icons['default'] ?? ''); // Fallback to default
        return wp_kses($svg_markup, $allowed_svg_tags);
    }

} // End class AwesomeBot_Frontend