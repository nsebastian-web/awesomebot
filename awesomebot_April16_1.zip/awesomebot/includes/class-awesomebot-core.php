<?php
/**
 * Core functionality handler for AwesomeBot.
 * Handles AJAX requests, orchestrates RAG (Q&A, Optional Query Rewrite, Vector Search, Re-ranking, Prompting, LLM),
 * manages history, logs chats, handles rating/transcripts.
 *
 * @package AwesomeBot
 * @since   1.0.0
 * @version 1.1.7 // Fixed parse error in find_and_rerank_chunks
 */

declare(strict_types=1);

if (!defined('ABSPATH')) { exit; }

// Ensure required background job functions are loaded.
if (defined('AWESOMEBOT_DIR') && file_exists(AWESOMEBOT_DIR . 'includes/background-jobs.php')) {
    require_once AWESOMEBOT_DIR . 'includes/background-jobs.php';
} else {
    if (defined('AWESOMEBOT_DIR') && file_exists(AWESOMEBOT_DIR . 'includes/class-awesomebot-logs.php')) {
        require_once AWESOMEBOT_DIR . 'includes/class-awesomebot-logs.php';
        if (class_exists('AwesomeBot_Logs')) { AwesomeBot_Logs::log('Critical Error: background-jobs.php not found. RAG functionality will fail.', 'error'); }
    }
}

/**
 * Class AwesomeBot_Core
 * Handles the main backend logic for chat interactions.
 */
class AwesomeBot_Core {

    // Constants for configuration and defaults
    private const MAX_QUERY_LENGTH = 500;
    private const DEFAULT_RAG_THRESHOLD = 0.55; // Default Vector relevance threshold *before* re-ranking
    private const DEFAULT_RAG_NUM_CHUNKS = 4;   // Default Final number of chunks *after* re-ranking
    private const DEFAULT_HISTORY_LIMIT = 10;   // Default Max history turns (user+model)
    private const RERANK_FETCH_MULTIPLIER = 5;  // Fetch top_k * 5 results for re-ranking
    private const RERANK_VECTOR_WEIGHT = 0.75;  // Weight for vector score in re-ranking
    private const RERANK_LEXICAL_WEIGHT = 0.25; // Weight for lexical score in re-ranking

    private ?AwesomeBot_Sources $sources_manager = null;

    // --- Constructor --- (No changes needed)
    public function __construct() { if (class_exists('AwesomeBot_Sources')) { $this->sources_manager = new AwesomeBot_Sources(); } else { if (class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log')) { AwesomeBot_Logs::log('Error: AwesomeBot_Sources class not found during Core initialization.', 'error'); } } add_action('wp_ajax_awesomebot_request', [$this, 'handle_request']); add_action('wp_ajax_nopriv_awesomebot_request', [$this, 'handle_request']); add_action('wp_ajax_awesomebot_console_request', [$this, 'handle_console_request']); add_action('wp_ajax_awesomebot_send_transcript', [$this, 'handle_send_transcript']); add_action('wp_ajax_awesomebot_rate_response', [$this, 'handle_rate_response']); }

    /**
     * Handles main chat requests. Orchestrates RAG flow.
     *
     * @param bool $is_console Flag if request is from console. Defaults to false.
     * @return void Outputs JSON response.
     */
    public function handle_request(bool $is_console = false): void {
        $log_func_available = class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log');
        $context_source_type = $is_console ? 'Console' : 'Widget';
        $request_start_time = microtime(true);

        // 1. Security Check
        $nonce_action = $is_console ? 'awesomebot_console_nonce' : 'awesomebot_nonce'; if (!check_ajax_referer($nonce_action, 'nonce', false)) { if ($log_func_available) { AwesomeBot_Logs::log("AJAX Error ({$context_source_type}): Invalid nonce '{$nonce_action}'.", 'error'); } wp_send_json_error(['message' => __('Security check failed.', 'awesomebot')], 403); return; }

        // 2. Get and Validate Input
        $original_query = isset($_POST['query']) ? sanitize_text_field(wp_unslash($_POST['query'])) : ''; if (empty(trim($original_query))) { wp_send_json_error(['message' => __('No question provided.', 'awesomebot')], 400); return; } if (mb_strlen($original_query, 'UTF-8') > self::MAX_QUERY_LENGTH) { wp_send_json_error(['message' => sprintf(__('Query is too long (max %d characters).', 'awesomebot'), self::MAX_QUERY_LENGTH)], 400); return; } $conversation_history = $this->sanitize_history($_POST['history'] ?? []); if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Received Query='{$original_query}', History Items=" . count($conversation_history), 'debug'); }

        // Initialize response variables
        $response = ''; $status = 'could_not_answer'; $sources_used = __('None', 'awesomebot'); $is_rag_response = false; $relevant_chunks_data = null; $query_for_vector_search = $original_query;

        // --- Start RAG Workflow ---
        try {
            // 3. Direct Q&A Check
            $qa_response = $this->get_response_from_qa($original_query);
            if (!empty($qa_response)) { $response = $qa_response; $status = 'could_answer'; $sources_used = $this->sources_manager instanceof AwesomeBot_Sources ? $this->sources_manager->get_used_sources() : __('Q&A Source', 'awesomebot'); if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 1 Result - Q&A Match Found.", 'info'); } }
            else {
                if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 1 Result - No Q&A Match.", 'debug'); }

                // 4. Optional Query Rewriting
                $enable_rewrite = (bool) get_option(AwesomeBot_Admin::QUERY_REWRITE_OPTION_KEY, 0); if ($enable_rewrite) { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 2 - Attempting Query Rewrite (Experimental). Original: '{$original_query}'", 'debug'); } $rewritten_query = $this->rewrite_query_for_rag($original_query); if ($rewritten_query && $rewritten_query !== $original_query) { $query_for_vector_search = $rewritten_query; if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 2 Result - Query rewritten to: '{$query_for_vector_search}'", 'info'); } } else { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 2 Result - Query rewrite failed or returned original. Using original: '{$original_query}'", 'debug'); } $query_for_vector_search = $original_query; } } else { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 2 Result - Query rewrite disabled. Using original query for vector search.", 'debug'); } $query_for_vector_search = $original_query; }

                // 5. Perform Vector Search & Re-ranking
                if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 3 - Attempting Vector Search & Re-ranking (Vector Query: '{$query_for_vector_search}', Lexical Query: '{$original_query}').", 'debug'); }
                $relevant_chunks_data = $this->find_and_rerank_chunks($query_for_vector_search, $original_query);

                // 6. Build RAG Prompt & Query LLM (if chunks found)
                if ($relevant_chunks_data !== null && !empty($relevant_chunks_data['chunks'])) { $num_chunks = count($relevant_chunks_data['chunks']); if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 3 Result - Found and re-ranked {$num_chunks} relevant chunk(s). Proceeding with RAG prompt.", 'info'); } $augmented_prompt = $this->build_rag_prompt($original_query, $relevant_chunks_data['chunks']); if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 4 - Calling Gemini with RAG prompt.", 'api'); } $gemini_response = $this->query_gemini_api($augmented_prompt, $conversation_history, true); if ($gemini_response !== null && !empty(trim($gemini_response)) && trim($gemini_response) !== 'Information not found in sources.') { $response = $gemini_response; $status = 'could_answer'; $is_rag_response = true; $source_refs = $relevant_chunks_data['source_refs']; $sources_used = !empty($source_refs) ? __('Retrieved Context', 'awesomebot') . ' (' . implode(', ', array_slice($source_refs, 0, 3)) . (count($source_refs) > 3 ? ', ...' : '') . ')' : __('Retrieved Context', 'awesomebot'); if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 4 Result - RAG Gemini Call Successful. Sources: {$sources_used}", 'info'); } } else { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 4 Result - RAG Gemini Call Failed, Returned Empty, or Stated 'Not Found'. Proceeding to fallback.", 'warning'); } $response = ''; } }
                else { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 3 Result - No relevant chunks found after vector search and re-ranking (or search failed).", 'debug'); } }

                // 7. Fallback: Direct Gemini Query (if needed)
                if (empty($response)) { $connect_options = get_option('awesomebot_connect_options', ['gemini_enabled' => true]); if (!empty($connect_options['gemini_enabled'])) { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 5 - Attempting Fallback Gemini Query using original query: '{$original_query}'.", 'info'); } $gemini_response = $this->query_gemini_api($original_query, $conversation_history, false); if ($gemini_response !== null && !empty(trim($gemini_response))) { $response = $gemini_response; $status = 'could_answer'; $sources_used = __('Gemini AI', 'awesomebot'); if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 5 Result - Fallback Gemini Query Successful.", 'info'); } } else { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 5 Result - Fallback Gemini Query Failed or Returned Empty.", 'warning'); } } } else { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 5 Result - Gemini Fallback Disabled. No answer found.", 'info'); } } }
            }

            // 8. Final Fallback Message
            if (empty($response)) { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Step 6 - Using Default 'Cannot Answer' Response.", 'warning'); } $response = __("I’m sorry, I don’t have enough information to answer that right now. Please try rephrasing your question or contact support.", 'awesomebot'); $status = 'could_not_answer'; $sources_used = __('None', 'awesomebot'); }

        } catch (\Throwable $e) { if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Unhandled exception during request processing: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), 'error'); } $response = __('An unexpected error occurred while processing your request. Please try again later.', 'awesomebot'); $status = 'could_not_answer'; $sources_used = __('Error', 'awesomebot'); $is_rag_response = false; }

        // 9. Log the Chat and Send the Response
        $chat_id = $this->log_chat($original_query, $response, $status, $sources_used);
        $request_duration = microtime(true) - $request_start_time;
        if ($log_func_available) { AwesomeBot_Logs::log("{$context_source_type}: Request handled. Status='{$status}', RAG={$is_rag_response}, Sources='{$sources_used}', Time=" . sprintf("%.3fs", $request_duration), 'info'); }
        wp_send_json_success(['response' => $response, 'chat_id' => $chat_id, 'is_rag' => $is_rag_response]);
    }

    // --- handle_console_request --- (No changes needed)
    public function handle_console_request(): void { $this->handle_request(true); }

    // --- sanitize_history --- (No changes needed)
    private function sanitize_history(mixed $raw_history): array { $sanitized_history = []; if (!is_array($raw_history)) { return $sanitized_history; } foreach ($raw_history as $turn) { if (!is_array($turn) || !isset($turn['role'], $turn['parts']) || !is_array($turn['parts']) || empty($turn['parts'])) { continue; } $sanitized_role = sanitize_key($turn['role']); if (!in_array($sanitized_role, ['user', 'model'], true)) { continue; } $sanitized_parts = []; foreach ($turn['parts'] as $part) { if (is_array($part) && isset($part['text']) && is_scalar($part['text'])) { $sanitized_text = sanitize_textarea_field(wp_unslash((string)$part['text'])); if (!empty(trim($sanitized_text))) { $sanitized_parts[] = ['text' => $sanitized_text]; } } } if (!empty($sanitized_parts)) { $sanitized_history[] = ['role' => $sanitized_role, 'parts' => $sanitized_parts]; } } $history_limit = max(0, (int) apply_filters('awesomebot_contextual_history_limit', self::DEFAULT_HISTORY_LIMIT)); if (count($sanitized_history) > $history_limit) { $sanitized_history = array_slice($sanitized_history, -$history_limit); } return $sanitized_history; }

    // --- get_response_from_qa --- (No changes needed)
    private function get_response_from_qa(string $query): string { return ($this->sources_manager instanceof AwesomeBot_Sources) ? $this->sources_manager->get_response($query) : ''; }

    /**
     * Rewrites the user query using Gemini for potentially better RAG retrieval.
     * Uses a more conservative prompt. Experimental feature.
     *
     * @param string $original_query The original user query.
     * @return string|null Rewritten query, or original query if failed/unchanged. Null on API error.
     */
    private function rewrite_query_for_rag(string $original_query): ?string {
         $log_func_available = class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log');
         // Conservative rewrite prompt
         $rewrite_prompt = sprintf(
             "Please review the following user query. Correct any typos and clarify it for better information retrieval against a knowledge base, focusing on the core intent. If the query is already clear and well-formed, return the original query exactly. Output ONLY the final query, with no preamble or explanation.\n\nOriginal Query: %s\n\nRevised Query:",
             $original_query
         );
         $current_model = get_option('awesomebot_connect_options', ['gemini_model' => 'gemini-1.5-flash-latest'])['gemini_model'] ?? 'gemini-1.5-flash-latest';
         $rewrite_model = $current_model;
         if ($log_func_available) { AwesomeBot_Logs::log("Query Rewrite: Sending original query '{$original_query}' to model '{$rewrite_model}' for rewriting.", 'api'); }
         $start_time = microtime(true);
         $rewritten_query_raw = $this->query_gemini_api($rewrite_prompt, [], false); // Minimal context
         $duration = microtime(true) - $start_time;

         if ($rewritten_query_raw !== null && !empty(trim($rewritten_query_raw))) {
             $rewritten_query = trim($rewritten_query_raw);
             $processed_original = $this->_core_preprocess_text_for_lexical($original_query);
             $processed_rewritten = $this->_core_preprocess_text_for_lexical($rewritten_query);
             if ($processed_rewritten !== $processed_original && !empty($processed_rewritten)) {
                  if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Query Rewrite: Success (%.3fs). Rewritten to: '%s'", $duration, $rewritten_query), 'info'); }
                 return $rewritten_query;
             } else { if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Query Rewrite: Rewritten query effectively same as original (%.3fs). Using original.", $duration), 'debug'); } }
         } else { if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Query Rewrite: Gemini call failed or returned empty (%.3fs). Using original.", $duration), 'warning'); } }
         return $original_query; // Fallback
    }


    /**
     * Finds relevant text chunks using Pinecone, validates against local DB, then re-ranks.
     *
     * @param string $query_for_embedding The query text for vector search.
     * @param string $original_query      The original user query for lexical re-ranking.
     * @return array{chunks: string[], source_refs: string[]}|null Filtered, re-ranked chunks and refs, or null.
     */
    private function find_and_rerank_chunks(string $query_for_embedding, string $original_query): ?array {
        global $wpdb;
        $log_func_available = class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log');
        $chunks_table = $wpdb->prefix . 'awesomebot_chunks';
        $overall_start_time = microtime(true);

        // --- 1. Check Dependencies & Settings ---
        if (!function_exists('awesomebot_get_embedding')) { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search Error: awesomebot_get_embedding function not found.", 'error'); } return null; }
        $gemini_api_key = get_option('awesomebot_gemini_api_key', ''); if (empty($gemini_api_key)) { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search Error: Gemini API Key missing.", 'error'); } return null; }
        $pinecone_settings_option_key = defined('AwesomeBot_Admin::PINECONE_SETTINGS_KEY') ? AwesomeBot_Admin::PINECONE_SETTINGS_KEY : 'awesomebot_pinecone_settings';
        $pinecone_settings = get_option($pinecone_settings_option_key, ['api_key' => '', 'index_host' => '']); $pinecone_api_key = $pinecone_settings['api_key'] ?? ''; $pinecone_index_host = $pinecone_settings['index_host'] ?? ''; if (empty($pinecone_api_key) || empty($pinecone_index_host)) { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search Error: Pinecone API Key or Index Host is missing.", 'error'); } return null; }
        if (strpos($pinecone_index_host, 'https://') !== 0 && strpos($pinecone_index_host, 'http://') !== 0) { $pinecone_index_host = 'https://' . $pinecone_index_host; } $pinecone_index_host = rtrim($pinecone_index_host, '/'); $pinecone_query_url = $pinecone_index_host . '/query';

        // --- 2. Get Query Embedding ---
        $embedding_start_time = microtime(true); $embedding_model = apply_filters('awesomebot_embedding_model', 'models/embedding-001');
        $query_vector = awesomebot_get_embedding($query_for_embedding, $embedding_model, $gemini_api_key);
        $embedding_duration = microtime(true) - $embedding_start_time; if ($query_vector === false) { if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Vector Search: Failed to get query embedding (%.3fs).", $embedding_duration), 'error'); } return null; } if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Vector Search: Query embedding generated for '%s' (%.3fs).", $query_for_embedding, $embedding_duration), 'perf_debug'); }

        // --- 3. Query Pinecone API ---
        $pinecone_start_time = microtime(true);
        $top_k_final = max(1, (int) apply_filters('awesomebot_rag_num_chunks', self::DEFAULT_RAG_NUM_CHUNKS)); // Use 4 default
        $top_k_initial = $top_k_final * self::RERANK_FETCH_MULTIPLIER; // Fetch 4*5 = 20 initially
        $pinecone_body = ['vector' => $query_vector, 'topK' => $top_k_initial, 'includeValues' => true, 'includeMetadata' => true];
        $json_pinecone_body = wp_json_encode($pinecone_body); if ($json_pinecone_body === false) { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search Error: Failed to JSON encode Pinecone request body.", 'error'); } return null; }
        $pinecone_args = ['method' => 'POST','headers' => ['Api-Key' => $pinecone_api_key, 'Content-Type' => 'application/json; charset=utf-8', 'Accept' => 'application/json'],'body' => $json_pinecone_body,'timeout' => 15];
        if ($log_func_available) { AwesomeBot_Logs::log("Vector Search: Querying Pinecone endpoint: " . $pinecone_query_url . " (topK={$top_k_initial} for re-ranking)", 'debug'); }
        $response = wp_remote_post($pinecone_query_url, $pinecone_args); $pinecone_duration = microtime(true) - $pinecone_start_time; if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Vector Search: Pinecone API call completed (%.3fs).", $pinecone_duration), 'perf_debug'); }
        if (is_wp_error($response)) { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search: Pinecone Query WP_Error: " . $response->get_error_message(), 'error'); } return null; }
        $status_code = wp_remote_retrieve_response_code($response); $response_body_raw = wp_remote_retrieve_body($response); $response_body = json_decode($response_body_raw, true); if ($status_code !== 200 || json_last_error() !== JSON_ERROR_NONE || !isset($response_body['matches'])) { $log_msg = "Vector Search: Pinecone Query Error - Status: {$status_code}, JSON Err: " . json_last_error_msg() . ". Body: " . mb_substr($response_body_raw, 0, 500, 'UTF-8') . "..."; if ($log_func_available) { AwesomeBot_Logs::log($log_msg, 'error'); } return null; }

        // --- 4. Filter Initial Results & Prepare Candidate Data ---
        $matches = $response_body['matches'];
        $candidate_scores_metadata = [];
        $threshold = (float) apply_filters('awesomebot_vector_relevance_threshold', self::DEFAULT_RAG_THRESHOLD); // Use 0.55 default
        if ($log_func_available) { AwesomeBot_Logs::log("Vector Search: Filtering " . count($matches) . " Pinecone results with initial threshold {$threshold}.", 'debug'); }
        if ($log_func_available && defined('WP_DEBUG') && WP_DEBUG) { $scores_log = array_map(fn($m) => ($m['id'] ?? '?') . ':' . sprintf("%.4f", $m['score'] ?? 0.0), $matches); AwesomeBot_Logs::log("Vector Search: Raw Scores Received: [" . implode(', ', $scores_log) . "]", 'debug'); }

        $chunk_ids_to_fetch_text = [];
        foreach ($matches as $match) {
            $score = $match['score'] ?? 0.0; $chunk_id_str = $match['id'] ?? null; $metadata = $match['metadata'] ?? null;
            if ($score >= $threshold && $chunk_id_str && $metadata && isset($metadata['meta_id'], $metadata['source_type'], $metadata['original_ref'])) {
                 $chunk_id_int = intval($chunk_id_str);
                 if ($chunk_id_int > 0 && !isset($candidate_scores_metadata[$chunk_id_int])) {
                      $chunk_ids_to_fetch_text[] = $chunk_id_int;
                      $candidate_scores_metadata[$chunk_id_int] = ['vector_score' => $score, 'metadata' => ['type' => sanitize_key($metadata['source_type']), 'ref' => sanitize_text_field($metadata['original_ref'])]];
                 }
            }
        }

        if (empty($chunk_ids_to_fetch_text)) { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search: No chunks met the initial threshold {$threshold}.", 'debug'); } return null; }

        // --- 5. Fetch Local Text & Build Valid Candidate List ---
        $db_fetch_start_time = microtime(true);
        if ($log_func_available) { AwesomeBot_Logs::log("Vector Search: Fetching text for " . count($chunk_ids_to_fetch_text) . " candidate chunk IDs from local DB: [" . implode(',', $chunk_ids_to_fetch_text) . "]", 'debug'); }
        $ids_placeholder = implode(',', array_fill(0, count($chunk_ids_to_fetch_text), '%d'));
        $sql = $wpdb->prepare("SELECT chunk_id, chunk_text FROM {$chunks_table} WHERE chunk_id IN ({$ids_placeholder})", $chunk_ids_to_fetch_text);
        $db_chunks = $wpdb->get_results($sql, OBJECT_K);
        if ($wpdb->last_error) { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search DB Error fetching candidate chunk text: " . $wpdb->last_error, 'error'); } return null; }
        $db_fetch_duration = microtime(true) - $db_fetch_start_time; if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Vector Search: Local DB candidate chunk text fetch took %.3fs.", $db_fetch_duration), 'perf_debug'); }

        $valid_candidates = [];
        foreach ($candidate_scores_metadata as $chunk_id => $data) {
             if (isset($db_chunks[$chunk_id]) && !empty(trim($db_chunks[$chunk_id]->chunk_text))) {
                 $valid_candidates[$chunk_id] = [ 'text' => $db_chunks[$chunk_id]->chunk_text, 'vector_score' => $data['vector_score'], 'metadata' => $data['metadata'] ];
             } else { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search Warning: Candidate Chunk ID {$chunk_id} (VecScore: " . sprintf('%.4f', $data['vector_score']) . ") not found in local DB or empty text. Skipping.", 'warning'); } }
        }

        if (empty($valid_candidates)) { if ($log_func_available) { AwesomeBot_Logs::log("Vector Search: No valid candidate chunks remaining after checking local DB.", 'debug'); } return null; }

        // --- 6. Re-rank Valid Candidates ---
        $rerank_start_time = microtime(true);
        $processed_original_query = $this->_core_preprocess_text_for_lexical($original_query); // Use internal helper

        foreach ($valid_candidates as $chunk_id => &$chunk_data) { // Use reference
            $processed_chunk_text = $this->_core_preprocess_text_for_lexical($chunk_data['text']);
            $lexical_score = $this->calculate_lexical_score($processed_original_query, $processed_chunk_text);
            $chunk_data['combined_score'] = (self::RERANK_VECTOR_WEIGHT * $chunk_data['vector_score']) + (self::RERANK_LEXICAL_WEIGHT * $lexical_score);
            $chunk_data['lexical_score'] = $lexical_score;
            if ($log_func_available && defined('WP_DEBUG') && WP_DEBUG) { AwesomeBot_Logs::log(sprintf("Re-rank Calc: ChunkID=%d, VScore=%.4f, LScore=%.4f, Combined=%.4f", $chunk_id, $chunk_data['vector_score'], $lexical_score, $chunk_data['combined_score']), 'debug'); }
        }
        unset($chunk_data);

        uasort($valid_candidates, function ($a, $b) { return ($b['combined_score'] ?? 0.0) <=> ($a['combined_score'] ?? 0.0); });
        $reranked_chunks_data = array_slice($valid_candidates, 0, $top_k_final, true);
        $rerank_duration = microtime(true) - $rerank_start_time;
        if ($log_func_available) { $reranked_ids_scores = array_map(fn($id, $data) => $id.':'.sprintf('%.4f', $data['combined_score']), array_keys($reranked_chunks_data), $reranked_chunks_data); AwesomeBot_Logs::log(sprintf("Vector Search: Re-ranking %d valid candidates took %.4fs. Selected top %d: [%s]", count($valid_candidates), $rerank_duration, count($reranked_chunks_data), implode(', ', $reranked_ids_scores)), 'perf_debug');}

        // --- 7. Prepare Final Output ---
        $final_chunks = []; $final_source_refs = [];
        foreach ($reranked_chunks_data as $chunk_id => $data) {
            $final_chunks[] = $data['text']; $meta = $data['metadata']; $ref_string = '';
            if ($meta['type'] === 'wp_content') { $post_id_ref = intval($meta['ref']); $post_title = ($post_id_ref > 0) ? get_the_title($post_id_ref) : null; $ref_string = $post_title ? $post_title : sprintf(__('Post ID %d', 'awesomebot'), $post_id_ref); }
            elseif ($meta['type'] === 'link') { $parsed_url = wp_parse_url($meta['ref']); $ref_string = $parsed_url['host'] ?? __('Web Source', 'awesomebot'); }
            elseif ($meta['type'] === 'file') { $ref_string = sprintf(__('File: %s', 'awesomebot'), basename($meta['ref'])); }
            else { $ref_string = ucfirst($meta['type']) . ': ' . basename($meta['ref']); }
            $final_source_refs[] = $ref_string;
        }

        $overall_duration = microtime(true) - $overall_start_time;
        if (!empty($final_chunks)) { if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Vector Search & Re-rank: Found %d relevant chunks in %.3f seconds.", count($final_chunks), $overall_duration), 'info'); } return ['chunks' => $final_chunks, 'source_refs' => array_unique($final_source_refs)]; }
        else { if ($log_func_available) { AwesomeBot_Logs::log(sprintf("Vector Search & Re-rank: No relevant chunks after re-ranking valid candidates (Total time: %.3fs).", $overall_duration), 'debug'); } return null; }
    }


    /**
     * Preprocesses text lightly for lexical score calculation. Internal helper.
     * Fixed fatal error by adding this method within the class.
     *
     * @param string $text Input text.
     * @return string Processed text.
     */
     private function _core_preprocess_text_for_lexical(string $text): string {
         $text = strtolower(trim($text));
         // Remove common punctuation marks using Unicode property escapes
         $text = preg_replace('/[\p{P}\p{S}]+/u', '', $text);
         $text = preg_replace('/\s+/u', ' ', $text); // Normalize whitespace
         return trim($text);
     }

     /**
      * Calculates a simple lexical score (token overlap focused on query terms). Used for re-ranking.
      *
      * @param string $processed_query Preprocessed original user query.
      * @param string $processed_chunk_text Preprocessed chunk text.
      * @return float Score between 0.0 and 1.0 based on query term overlap.
      */
     private function calculate_lexical_score(string $processed_query, string $processed_chunk_text): float {
         if (empty($processed_query) || empty($processed_chunk_text)) { return 0.0; }
         $query_words = array_unique(preg_split('/\s+/u', $processed_query, -1, PREG_SPLIT_NO_EMPTY) ?: []);
         $chunk_words = array_unique(preg_split('/\s+/u', $processed_chunk_text, -1, PREG_SPLIT_NO_EMPTY) ?: []);
         if (empty($query_words) || empty($chunk_words)) { return 0.0; }
         $intersection = array_intersect($query_words, $chunk_words);
         // Score based on how many query words are present in the chunk
         $score = count($intersection) / count($query_words);
         return round(max(0.0, min(1.0, $score)), 4);
     }

    /**
     * Builds the augmented prompt text for RAG calls. Refined instructions.
     *
     * @param string $user_query Original user query.
     * @param array<string> $context_chunks Relevant text chunks.
     * @return string The augmented prompt text.
     */
    private function build_rag_prompt(string $user_query, array $context_chunks): string {
        $system_prompt = get_option('awesomebot_system_prompt', 'Be helpful and friendly.');
        if (empty(trim($system_prompt))) { $system_prompt = 'Be helpful and friendly.'; }
        $context_string = implode("\n\n---\n\n", $context_chunks);

        // Refined Prompt Instructions V4
        $prompt_lines = [
            trim($system_prompt), "",
            "**CRITICAL INSTRUCTION:** Answer the user's question below.",
            "Base your answer **strictly and exclusively** on the information contained within the following 'Context Snippets'.",
            "Do **NOT** use any external knowledge or information outside of these provided snippets.",
            "Synthesize the information from the snippets if necessary to form a complete and coherent answer.",
            "If the provided context snippets do not contain the information needed to answer the question, you **MUST** respond with **ONLY** the exact phrase: `Information not found in sources.`",
            "", "**Context Snippets:**", "-----------------", $context_string, "-----------------", "", "**User Question:**", $user_query
        ];
        $prompt = implode("\n", $prompt_lines);
        if (class_exists('AwesomeBot_Logs') && defined('WP_DEBUG') && WP_DEBUG) { $log_context = mb_substr($context_string, 0, 500, 'UTF-8') . (mb_strlen($context_string, 'UTF-8') > 500 ? '...' : ''); AwesomeBot_Logs::log("Built RAG Prompt Context Snippet (first 500 chars):\n{$log_context}", 'debug'); }
        return $prompt;
    }

    // --- query_gemini_api --- (No changes needed)
     private function query_gemini_api(string $current_prompt, array $conversation_history = [], bool $is_rag_prompt = false): ?string { $log_func_available = class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log'); $api_key = get_option('awesomebot_gemini_api_key', ''); $connect_options = get_option('awesomebot_connect_options', ['gemini_enabled' => true, 'gemini_model' => 'gemini-1.5-flash-latest']); if (empty($api_key) || empty($connect_options['gemini_enabled'])) { if ($log_func_available) { AwesomeBot_Logs::log('Gemini API query skipped (API Key missing or Gemini disabled in settings).', 'debug'); } return null; } $model_name = preg_replace('/[^a-zA-Z0-9\-\.]/', '', $connect_options['gemini_model'] ?? 'gemini-1.5-flash-latest'); if (empty($model_name)) { $model_name = 'gemini-1.5-flash-latest'; } $api_endpoint = "https://generativelanguage.googleapis.com/v1beta/models/{$model_name}:generateContent"; $url = add_query_arg('key', $api_key, $api_endpoint); $final_contents = []; $system_prompt = trim(get_option('awesomebot_system_prompt', '')); if (!$is_rag_prompt && !empty($system_prompt)) { $final_contents[] = ['role' => 'user', 'parts' => [['text' => "System Instructions: " . $system_prompt]]]; $final_contents[] = ['role' => 'model', 'parts' => [['text' => 'OK.']]]; } $final_contents = array_merge($final_contents, $conversation_history); $final_contents[] = ['role' => 'user', 'parts' => [['text' => $current_prompt]]]; $safety_settings = [['category' => 'HARM_CATEGORY_HATE_SPEECH', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],['category' => 'HARM_CATEGORY_HARASSMENT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],['category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],['category' => 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE']]; $generation_config = ['temperature' => (float) apply_filters('awesomebot_gemini_temperature', 0.7)]; $body = ['contents'=> $final_contents,'safetySettings'=> $safety_settings,'generationConfig'=> $generation_config]; $json_body = wp_json_encode($body); if ($json_body === false) { if ($log_func_available) { AwesomeBot_Logs::log("Gemini API Error: Failed to JSON encode request body.", 'error'); } return null; } $args = ['method'=> 'POST','headers'=> ['Content-Type' => 'application/json; charset=utf-8'],'body'=> $json_body,'timeout'=> 45]; if ($log_func_available) { AwesomeBot_Logs::log("Sending request to Gemini API ({$model_name})" . ($is_rag_prompt ? " (RAG)" : " (Fallback)"), 'api'); } $response = wp_remote_post($url, $args); if (is_wp_error($response)) { if ($log_func_available) { AwesomeBot_Logs::log("Gemini API WP_Error: " . $response->get_error_message(), 'error'); } return null; } $status_code = wp_remote_retrieve_response_code($response); $response_body_raw = wp_remote_retrieve_body($response); $response_body = json_decode($response_body_raw, true); if ($status_code !== 200 || json_last_error() !== JSON_ERROR_NONE) { $log_message = "Gemini API Error - Status: {$status_code}, JSON Err: " . json_last_error_msg() . ". Body: " . mb_substr($response_body_raw, 0, 500, 'UTF-8') . "..."; if ($log_func_available) { AwesomeBot_Logs::log($log_message, 'error'); } if (isset($response_body['error']['message']) && $log_func_available) { AwesomeBot_Logs::log("Gemini API Specific Error: " . sanitize_text_field($response_body['error']['message']), 'error'); } return null; } $text = $response_body['candidates'][0]['content']['parts'][0]['text'] ?? null; $finish_reason = $response_body['candidates'][0]['finishReason'] ?? 'UNKNOWN'; if (empty(trim((string)$text))) { if ($log_func_available) { AwesomeBot_Logs::log("Gemini API returned empty text content. Finish Reason: '{$finish_reason}'.", 'warning'); } if ($finish_reason === 'SAFETY' && isset($response_body['promptFeedback']['blockReason'])) { if ($log_func_available) { AwesomeBot_Logs::log("Gemini API response blocked due to safety settings. Reason: " . sanitize_text_field($response_body['promptFeedback']['blockReason']), 'warning'); } return __('My response was blocked due to safety settings.', 'awesomebot'); } return null; } if ($log_func_available) { AwesomeBot_Logs::log('Gemini API response received successfully.' . ($is_rag_prompt ? " (RAG)" : " (Fallback)"), 'debug'); } return trim((string)$text); }

    /**
     * Logs chat interaction. Uses append and slice, logs update status.
     *
     * @param string $question User's question.
     * @param string $answer Bot's answer.
     * @param string $status 'could_answer', 'could_not_answer', 'error'.
     * @param string $sources Source information string.
     * @return int Chat ID (array key).
     */
    private function log_chat(string $question, string $answer, string $status, string $sources): int {
        $log_func_available = class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log');
        if ($log_func_available) { AwesomeBot_Logs::log("Attempting to log chat interaction...", 'debug'); }
        $history_option_key = 'awesomebot_chat_history'; $history = get_option($history_option_key, []); if (!is_array($history)) { if ($log_func_available) { AwesomeBot_Logs::log("Chat Logging Error: {$history_option_key} option is not an array. Resetting.", 'warning'); } $history = []; }
        $user_display_name = __('Guest', 'awesomebot'); $user_email = __('N/A', 'awesomebot'); if (is_user_logged_in()) { $current_user = wp_get_current_user(); if ($current_user instanceof WP_User && $current_user->exists()) { $user_display_name = $current_user->display_name; $user_email = $current_user->user_email; } }
        $chat_entry = [ 'user' => $user_display_name, 'email' => $user_email, 'question' => $question, 'answer' => $answer, 'status' => sanitize_key($status), 'sources' => sanitize_text_field($sources), 'timestamp' => current_time('mysql', true), 'rating' => null ];
        $history[] = $chat_entry; // Append
        $max_history = max(100, (int) apply_filters('awesomebot_max_chat_history', 5000)); if (count($history) > $max_history) { $history = array_slice($history, -$max_history); if ($log_func_available) { AwesomeBot_Logs::log("Chat history rotation applied. Kept latest {$max_history} entries.", 'debug'); } }
        $updated = update_option($history_option_key, $history, false);
        $chat_id = empty($history) ? 0 : max(array_keys($history)); // Get highest key
        if ($log_func_available) { $log_status = $updated ? 'succeeded' : 'FAILED (or no change)'; AwesomeBot_Logs::log("Chat logged - User: {$user_display_name}, Status: {$status}, Sources: {$sources}, Assigned Chat ID: {$chat_id}. Update Option: {$log_status}", 'chat'); if ($updated === false && $status !== 'error') { AwesomeBot_Logs::log("Chat Logging Warning: update_option returned false. History might not be saved correctly.", 'warning'); } }
        return (int) $chat_id;
    }


    // --- handle_send_transcript --- (No changes needed)
     public function handle_send_transcript(): void { global $ts_mail_errors; $log_func_available = class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log'); check_ajax_referer('awesomebot_console_nonce', 'nonce'); $transcript = isset($_POST['transcript']) ? sanitize_textarea_field(wp_unslash($_POST['transcript'])) : ''; if (empty(trim($transcript))) { wp_send_json_error(['message' => __('No transcript content received.', 'awesomebot')], 400); return; } $support_email_option = get_option('awesomebot_support_email', ''); $recipient_email = is_email($support_email_option) ? $support_email_option : ''; if (empty($recipient_email)) { if ($log_func_available) { AwesomeBot_Logs::log("Transcript send failed: Support email address is not configured or invalid.", 'email'); } wp_send_json_error(['message' => __('Support email address is not configured correctly in plugin settings.', 'awesomebot')], 400); return; } $site_name = get_bloginfo('name'); $site_domain = wp_parse_url(home_url(), PHP_URL_HOST) ?: 'localhost'; $from_email = apply_filters('awesomebot_transcript_from_email', "no-reply@" . $site_domain); $from_name = apply_filters('awesomebot_transcript_from_name', $site_name); $subject = sprintf(__('[%s] Chat Transcript', 'awesomebot'), $site_name); $headers = ['Content-Type: text/plain; charset=UTF-8',"From: \"{$from_name}\" <{$from_email}>","Reply-To: {$recipient_email}"]; $ip_address = $_SERVER['REMOTE_ADDR'] ?? __('N/A', 'awesomebot'); $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? __('N/A', 'awesomebot'); $timestamp = current_time('mysql'); $message = sprintf(__("Chat transcript generated by AwesomeBot on %s:", 'awesomebot'), home_url()) . "\n" . sprintf(__('Timestamp: %s', 'awesomebot'), $timestamp) . "\n" . sprintf(__('User IP: %s', 'awesomebot'), $ip_address) . "\n" . sprintf(__('User Agent: %s', 'awesomebot'), $user_agent) . "\n\n----------------------------------------\nTRANSCRIPT START\n----------------------------------------\n\n" . $transcript . "\n\n----------------------------------------\nTRANSCRIPT END\n----------------------------------------\n"; $sent = wp_mail($recipient_email, $subject, $message, $headers); if ($sent) { if ($log_func_available) { AwesomeBot_Logs::log("Chat transcript successfully sent to {$recipient_email}", 'email'); } wp_send_json_success(['message' => __('Transcript sent successfully.', 'awesomebot')]); } else { $error_message = __('Unknown mail error occurred.', 'awesomebot'); $phpmailer_error = ''; global $phpmailer; if (isset($phpmailer) && $phpmailer instanceof PHPMailer\PHPMailer\PHPMailer) { $phpmailer_error = $phpmailer->ErrorInfo; } if (!empty($phpmailer_error)) { $error_message = $phpmailer_error; } elseif (!empty($ts_mail_errors) && is_array($ts_mail_errors)) { $error_message = implode('; ', $ts_mail_errors); } if ($log_func_available) { AwesomeBot_Logs::log("Failed to send transcript to {$recipient_email}. Error: " . $error_message, 'error'); } wp_send_json_error(['message' => __('Failed to send transcript. Please check site email configuration and logs.', 'awesomebot')], 500); } }

    // --- handle_rate_response --- (No changes needed)
     public function handle_rate_response(): void { $log_func_available = class_exists('AwesomeBot_Logs') && method_exists('AwesomeBot_Logs', 'log'); check_ajax_referer('awesomebot_console_nonce', 'nonce'); $chat_id_input = $_POST['chat_id'] ?? '-1'; $rating = isset($_POST['rating']) ? sanitize_key($_POST['rating']) : ''; $chat_id = filter_var($chat_id_input, FILTER_VALIDATE_INT); if ($chat_id === false || $chat_id < 0 || !in_array($rating, ['thumbs_up', 'thumbs_down'], true)) { wp_send_json_error(['message' => __('Invalid chat ID or rating value provided.', 'awesomebot')], 400); return; } $history_option_key = 'awesomebot_chat_history'; $history = get_option($history_option_key, []); if (!is_array($history)) { if ($log_func_available) { AwesomeBot_Logs::log("Rating Error: Chat history option is not an array.", 'error'); } wp_send_json_error(['message' => __('Chat history data is invalid.', 'awesomebot')], 500); return; } if (isset($history[$chat_id])) { $history[$chat_id]['rating'] = $rating; $updated = update_option($history_option_key, $history, false); if ($updated) { if ($log_func_available) { AwesomeBot_Logs::log("Response rating recorded - ID: {$chat_id}, Rating: {$rating}", 'rating'); } wp_send_json_success(['message' => __('Rating recorded successfully.', 'awesomebot')]); } else { if ($log_func_available) { AwesomeBot_Logs::log("Rating processed for ID: {$chat_id} (update_option returned false - maybe no change or DB issue?).", 'debug'); } wp_send_json_success(['message' => __('Rating processed.', 'awesomebot')]); } } else { if ($log_func_available) { AwesomeBot_Logs::log("Rating Error: Chat entry ID '{$chat_id}' not found in history.", 'warning'); } wp_send_json_error(['message' => __('Chat entry not found.', 'awesomebot')], 404); } }

} // End class AwesomeBot_Core