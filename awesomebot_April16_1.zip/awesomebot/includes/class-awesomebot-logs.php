<?php
/**
 * Handles logging functionality for the AwesomeBot plugin.
 *
 * Provides static methods to write log messages to a WordPress option
 * and to render the log viewer interface within the admin settings page.
 * Logs are automatically rotated to prevent excessive database growth.
 *
 * @package AwesomeBot
 * @since   1.0.0
 * @version 1.1.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Class AwesomeBot_Logs
 *
 * Static class for handling plugin logging.
 */
class AwesomeBot_Logs {

    /**
     * Option key where logs are stored in wp_options table.
     *
     * @since 1.0.3
     * @var string
     */
    private const LOG_OPTION_KEY = 'awesomebot_logs';

    /**
     * Default maximum number of log entries to keep.
     * Filterable via 'awesomebot_max_log_entries'.
     *
     * @since 1.0.0
     * @var int
     */
    private const DEFAULT_MAX_LOG_ENTRIES = 1000;

    /**
     * Minimum number of log entries to keep after filtering.
     * Prevents setting the limit too low via the filter.
     *
     * @since 1.1.0
     * @var int
     */
    private const MIN_LOG_ENTRIES = 50;

    /**
     * Logs a message to the AwesomeBot logs option.
     *
     * Automatically rotates logs, keeping only the most recent entries defined
     * by the 'awesomebot_max_log_entries' filter or the default limit.
     * Messages and types are sanitized. Timestamps are stored in GMT.
     *
     * @since 1.0.0
     * @param string $message The message string to log.
     * @param string $type    Optional. The type/category of the log entry
     * (e.g., 'general', 'error', 'api', 'email', 'background_job', 'admin_action', 'debug', 'rating', 'chat').
     * Defaults to 'general'.
     * @return void
     */
    public static function log(string $message, string $type = 'general'): void {
        // Sanitize inputs.
        $type = sanitize_key($type);
        if (empty($type)) {
            $type = 'general'; // Ensure a default type.
        }
        // Use sanitize_textarea_field for potentially longer messages, though sanitize_text_field might suffice.
        $message = sanitize_textarea_field($message);

        // Get existing logs; ensure it is an array.
        $logs = get_option(self::LOG_OPTION_KEY, []);
        if (!is_array($logs)) {
            $logs = []; // Reset if the option somehow got corrupted.
        }

        // Prepare the new log entry.
        $new_log_entry = [
            'timestamp' => current_time('mysql', true), // Use GMT timestamp for consistency.
            'message'   => $message,
            'type'      => $type,
        ];

        // Add the new entry to the beginning (newest first internally).
        array_unshift($logs, $new_log_entry);

        // Determine the maximum number of log entries.
        $max_log_entries = (int) apply_filters('awesomebot_max_log_entries', self::DEFAULT_MAX_LOG_ENTRIES);
        // Ensure a sensible minimum limit.
        $max_log_entries = max(self::MIN_LOG_ENTRIES, $max_log_entries);

        // Rotate logs if limit exceeded. Keep the newest $max_log_entries.
        if (count($logs) > $max_log_entries) {
            $logs = array_slice($logs, 0, $max_log_entries);
        }

        // Save logs back to the database (disable autoload for performance).
        update_option(self::LOG_OPTION_KEY, $logs, false);
    }

    /**
     * Renders the Logs admin page content (intended for use within a settings tab).
     * Displays logs with filtering by type and an option to clear logs.
     *
     * @since 1.0.0
     * @since 1.1.0 Added nonce/caps check for clear action, improved display logic.
     * @return void Outputs HTML directly.
     */
    public static function render_admin_page(): void {
        $logs = get_option(self::LOG_OPTION_KEY, []);
        if (!is_array($logs)) { $logs = []; } // Ensure it's an array.

        $type_filter = isset($_GET['log_type']) ? sanitize_key($_GET['log_type']) : 'all';
        $notice = '';

        // --- Handle Log Clearing POST Action ---
        // Check if the clear logs button was pressed, nonce is valid, and user has permission.
        if (isset($_POST['clear_logs'])
            && isset($_POST['_wpnonce_logs_clear'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce_logs_clear'])), 'awesomebot_logs_clear')
        ) {
            if (current_user_can('manage_options')) {
                update_option(self::LOG_OPTION_KEY, [], false); // Clear logs option.
                $logs = []; // Update the display immediately.
                $type_filter = 'all'; // Reset filter after clearing.
                $notice = sprintf(
                    '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
                    esc_html__('Logs cleared successfully.', 'awesomebot')
                );
                // Self-log the clear action if possible (will be immediately cleared, but good practice).
                self::log('Logs cleared by user.', 'admin_action');
            } else {
                // Permission denied notice.
                $notice = sprintf(
                    '<div class="notice notice-error is-dismissible"><p>%s</p></div>',
                    esc_html__('Permission denied.', 'awesomebot')
                );
            }
        } // End POST handling.

        // Filter logs if a specific type is selected.
        $filtered_logs = $logs; // Start with all logs (which are already newest first).
        if ($type_filter !== 'all') {
            $filtered_logs = array_filter($logs, function ($log) use ($type_filter) {
                return (($log['type'] ?? 'general') === $type_filter);
            });
        }

        // Build list of unique log types present in the current logs for the filter dropdown.
        $log_types_present = [
            'all' => __('All Types', 'awesomebot'), // Always include 'All'
        ];
        if (!empty($logs)) {
            // Extract the 'type' column efficiently.
            $types_in_logs = array_column($logs, 'type');
            // Get unique types, remove potential empty values, sort alphabetically.
            $unique_types = array_filter(array_unique($types_in_logs));
            sort($unique_types);

            foreach ($unique_types as $type) {
                 // Generate a human-readable label from the type key.
                 $label = ucwords(str_replace(['_', '-'], ' ', sanitize_text_field($type)));
                 $log_types_present[sanitize_key($type)] = $label;
            }
        }
        ?>
        <div class="wrap awesomebot-admin">
            <h2><?php esc_html_e('AwesomeBot Logs', 'awesomebot'); ?></h2>
            <p><?php esc_html_e('View recent activity and debugging messages from the AwesomeBot plugin.', 'awesomebot'); ?></p>
            <?php echo wp_kses_post($notice); // Display action notices. ?>

            <div class="awesomebot-filters" style="padding: 16px 0; border-bottom: none;">
                <form method="get" class="awesomebot-filter-form">
                    <input type="hidden" name="page" value="awesomebot"> <?php // Assumes logs are shown on main settings page. ?>
                    <input type="hidden" name="tab" value="logs-tab"> <?php // Ensures the logs tab remains active after filtering. ?>
                    <div class="awesomebot-filter-group">
                        <label for="log_type"><?php esc_html_e('Filter by Type:', 'awesomebot'); ?></label>
                        <select name="log_type" id="log_type">
                            <?php foreach ($log_types_present as $key => $label) : ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($type_filter, $key); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="submit" class="button button-secondary" value="<?php esc_attr_e('Filter Logs', 'awesomebot'); ?>">
                    </div>
                </form>

                <form method="post" class="awesomebot-action-buttons-form">
                    <?php wp_nonce_field('awesomebot_logs_clear', '_wpnonce_logs_clear'); ?>
                    <div class="awesomebot-action-buttons">
                        <input type="submit" name="clear_logs" class="button awesomebot-clear-button"
                               value="<?php esc_attr_e('Clear All Logs', 'awesomebot'); ?>"
                               onclick="return confirm('<?php esc_attr_e('Are you sure you want to permanently delete all AwesomeBot logs? This action cannot be undone.', 'awesomebot'); ?>');"
                               <?php disabled(empty($logs)); // Disable if there are no logs to clear. ?>
                               aria-label="<?php esc_attr_e('Permanently clear all log entries', 'awesomebot'); ?>">
                    </div>
                </form>
            </div>

            <div class="awesomebot-table-container">
                <?php if (empty($filtered_logs)) : ?>
                    <p style="margin-top: 15px; padding: 20px; text-align: center;">
                        <?php echo ($type_filter !== 'all')
                            ? esc_html__('No logs found for the selected type.', 'awesomebot')
                            : esc_html__('No logs available.', 'awesomebot'); ?>
                    </p>
                <?php else : ?>
                    <table class="wp-list-table widefat fixed striped awesomebot-data-table" style="margin-top: 15px;">
                        <thead>
                            <tr>
                                <th style="width: 20%;"><?php esc_html_e('Timestamp', 'awesomebot'); ?></th>
                                <th style="width: 15%;"><?php esc_html_e('Type', 'awesomebot'); ?></th>
                                <th style="width: 65%;"><?php esc_html_e('Message', 'awesomebot'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($filtered_logs as $log_entry) : // Iterate directly (already newest first). ?>
                                <tr>
                                    <td>
                                        <?php
                                            // Display timestamp using WP's date/time format settings.
                                            $timestamp_gmt = $log_entry['timestamp'] ?? 'now';
                                            $datetime = date_create($timestamp_gmt, new DateTimeZone('GMT'));
                                            if ($datetime) {
                                                $timestamp_local = $datetime->getTimestamp() + (int) get_option('gmt_offset') * HOUR_IN_SECONDS;
                                                echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), $timestamp_local));
                                            } else {
                                                echo esc_html($timestamp_gmt); // Fallback if date creation fails.
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                            // Display formatted type.
                                            $type_key = $log_entry['type'] ?? 'general';
                                            $type_display = $log_types_present[$type_key] ?? ucfirst(str_replace(['_', '-'], ' ', $type_key));
                                            echo esc_html($type_display);
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo esc_html($log_entry['message'] ?? ''); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div> <?php // End wrap ?>
        <?php
    }

} // End class AwesomeBot_Logs