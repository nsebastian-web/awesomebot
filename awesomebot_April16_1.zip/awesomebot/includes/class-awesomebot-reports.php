<?php
/**
 * Handles generating and displaying basic reports for AwesomeBot.
 * Calculates stats based on chat history, allowing date filtering.
 * Renders the admin page for reports.
 *
 * @package AwesomeBot
 * @since   1.0.1
 * @version 1.1.0
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Class AwesomeBot_Reports
 *
 * Handles reporting functionality.
 */
class AwesomeBot_Reports {

    /**
     * Option key for chat history storage.
     * @since 1.1.0
     */
    private const HISTORY_OPTION_KEY = 'awesomebot_chat_history';

    /**
     * Renders the reports admin page content.
     * Fetches chat history, applies date filters from GET parameters,
     * generates statistics using the generate_stats() helper method,
     * and displays the calculated statistics in a simple table format.
     * Includes a date range picker for filtering the data.
     *
     * @since 1.0.1
     * @return void Outputs HTML directly.
     */
    public static function render_admin_page(): void {
        // Retrieve chat history from options, ensure it's an array.
        $history = get_option(self::HISTORY_OPTION_KEY, []);
        if (!is_array($history)) {
            $history = [];
        }

        // Get date filters from GET request and sanitize them.
        $start_date_str = isset($_GET['start_date']) ? sanitize_text_field(wp_unslash($_GET['start_date'])) : '';
        $end_date_str   = isset($_GET['end_date']) ? sanitize_text_field(wp_unslash($_GET['end_date'])) : '';
        $filtered_history = $history; // Default to all history.
        $notice = '';
        $filter_active = false;

        // Apply date filtering if both dates are provided and valid.
        if (!empty($start_date_str) && !empty($end_date_str)) {
            try {
                $filter_start_dt = new DateTime($start_date_str . ' 00:00:00');
                $filter_end_dt   = new DateTime($end_date_str . ' 23:59:59');

                // Basic check: ensure end date is not before start date.
                if ($filter_end_dt < $filter_start_dt) {
                    throw new Exception(__('End date cannot be before start date.', 'awesomebot'));
                }

                $filter_start_time = $filter_start_dt->getTimestamp();
                $filter_end_time   = $filter_end_dt->getTimestamp();
                $filter_active = true; // Mark filters as active for display text

                // Filter the history array based on the timestamp range.
                $filtered_history = array_filter($history, function ($entry) use ($filter_start_time, $filter_end_time) {
                    if (!isset($entry['timestamp'])) {
                        return false; // Skip entries without a timestamp
                    }
                    try {
                        // Assume timestamps are stored in MySQL format (GMT).
                        $entry_dt = new DateTime($entry['timestamp']);
                        return ($entry_dt->getTimestamp() >= $filter_start_time && $entry_dt->getTimestamp() <= $filter_end_time);
                    } catch (Exception $e) {
                        // Ignore entries with invalid timestamps during filtering.
                        return false;
                    }
                });
            } catch (Exception $e) {
                // Handle invalid date formats or ranges.
                $notice = sprintf(
                    '<div class="notice notice-warning is-dismissible"><p>%s %s</p></div>',
                    esc_html__('Invalid date format or range provided for filtering.', 'awesomebot'),
                    esc_html('(' . $e->getMessage() . ')') // Show specific error if available
                );
                // Reset dates and show all history on error.
                $start_date_str = '';
                $end_date_str   = '';
                $filtered_history = $history;
                $filter_active = false;
            }
        }

        // Generate statistics based on the (potentially filtered) history.
        $stats = self::generate_stats($filtered_history);

        // --- Render Page HTML ---
        ?>
        <div class="wrap awesomebot-admin">
            <h1><?php esc_html_e('AwesomeBot Reports', 'awesomebot'); ?></h1>
            <?php echo wp_kses_post($notice); // Display any notices ?>

            <div class="awesomebot-card">
                <div class="awesomebot-card-header">
                    <div class="awesomebot-card-title-section">
                        <h2 class="awesomebot-card-title"><?php esc_html_e('Filter Reports by Date', 'awesomebot'); ?></h2>
                    </div>
                </div>
                <div class="awesomebot-filters">
                    <form method="get" class="awesomebot-filter-form">
                        <input type="hidden" name="page" value="awesomebot-reports">
                        <div class="awesomebot-filter-group">
                            <label for="start_date"><?php esc_html_e('Date Range:', 'awesomebot'); ?></label>
                            <input type="text" name="start_date" id="start_date" value="<?php echo esc_attr($start_date_str); ?>" class="date-picker" placeholder="<?php esc_attr_e('Start Date', 'awesomebot'); ?>" autocomplete="off">
                            <span>&ndash;</span>
                            <input type="text" name="end_date" id="end_date" value="<?php echo esc_attr($end_date_str); ?>" class="date-picker" placeholder="<?php esc_attr_e('End Date', 'awesomebot'); ?>" autocomplete="off">
                        </div>
                        <input type="submit" class="button button-secondary awesomebot-filter-button" value="<?php esc_attr_e('Filter', 'awesomebot'); ?>">
                        <?php if ($filter_active) : // Show Clear Filters button only if filters are applied ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=awesomebot-reports')); ?>" class="button button-secondary"><?php esc_html_e('Clear Filters', 'awesomebot'); ?></a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="awesomebot-card report-section">
                <div class="awesomebot-card-header">
                    <div class="awesomebot-card-title-section">
                        <h2 class="awesomebot-card-title"><?php esc_html_e('Chat Statistics', 'awesomebot'); ?></h2>
                         <p class="awesomebot-card-description">
                            <?php
                            echo $filter_active
                                ? sprintf(
                                    /* translators: 1: Start date, 2: End date */
                                    esc_html__('Displaying stats from %1$s to %2$s', 'awesomebot'),
                                    esc_html($start_date_str), // Already sanitized
                                    esc_html($end_date_str)  // Already sanitized
                                )
                                : esc_html__('Displaying overall stats', 'awesomebot');
                            ?>
                        </p>
                    </div>
                </div>
                <?php if (empty($history) && !$filter_active) : // No history at all ?>
                    <div style="padding: 20px; text-align: center;">
                        <p><?php esc_html_e('No chat history recorded yet.', 'awesomebot'); ?></p>
                    </div>
                <?php elseif (empty($filtered_history) && $filter_active) : // Filters applied, but no results ?>
                    <div style="padding: 20px; text-align: center;">
                        <p><?php esc_html_e('No data available for the selected date range.', 'awesomebot'); ?></p>
                    </div>
                <?php else : // Data available ?>
                    <div class="awesomebot-table-container">
                        <table class="widefat striped" style="width: 100%; margin: 0;">
                            <tbody>
                                <tr>
                                    <td style="width: 50%; padding: 12px; font-weight: 500;"><?php esc_html_e('Total Queries in Period', 'awesomebot'); ?></td>
                                    <td style="padding: 12px;"><?php echo esc_html(number_format_i18n($stats['total_queries'])); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px; font-weight: 500;"><?php esc_html_e('Successful Answers', 'awesomebot'); ?></td>
                                    <td style="padding: 12px;"><?php printf('%s (%s%%)', esc_html(number_format_i18n($stats['successful_answers'])), esc_html($stats['success_rate'])); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px; font-weight: 500;"><?php esc_html_e('Unanswered / Default Fallback', 'awesomebot'); ?></td>
                                    <td style="padding: 12px;"><?php printf('%s (%s%%)', esc_html(number_format_i18n($stats['unanswered_queries'])), esc_html($stats['unanswered_rate'])); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px; font-weight: 500;"><?php esc_html_e('Positive Ratings (Thumbs Up)', 'awesomebot'); ?></td>
                                    <td style="padding: 12px;"><?php printf('%s (%s%% of rated)', esc_html(number_format_i18n($stats['positive_ratings'])), esc_html($stats['positive_rating_rate'])); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px; font-weight: 500;"><?php esc_html_e('Negative Ratings (Thumbs Down)', 'awesomebot'); ?></td>
                                    <td style="padding: 12px;"><?php printf('%s (%s%% of rated)', esc_html(number_format_i18n($stats['negative_ratings'])), esc_html($stats['negative_rating_rate'])); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px; font-weight: 500;"><?php esc_html_e('Most Common Answer Source', 'awesomebot'); ?></td>
                                    <td style="padding: 12px;"><?php echo esc_html($stats['most_common_source'] ?: __('N/A', 'awesomebot')); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Calculates basic statistics from a given chat history array.
     *
     * @since 1.0.1
     * @access private
     * @param array<int, array<string, mixed>> $history Filtered or complete chat history array.
     * @return array{
     * total_queries: int,
     * successful_answers: int,
     * unanswered_queries: int,
     * success_rate: float,
     * unanswered_rate: float,
     * positive_ratings: int,
     * negative_ratings: int,
     * positive_rating_rate: float,
     * negative_rating_rate: float,
     * most_common_source: string
     * } Associative array of calculated statistics.
     */
    private static function generate_stats(array $history): array {
        $total_queries      = count($history);
        $successful_answers = 0;
        $positive_ratings   = 0;
        $negative_ratings   = 0;
        $sources_tally      = [];

        foreach ($history as $entry) {
            // Count successful answers
            if (($entry['status'] ?? '') === 'could_answer') {
                $successful_answers++;
            }

            // Count ratings
            if (isset($entry['rating'])) {
                if ($entry['rating'] === 'thumbs_up') {
                    $positive_ratings++;
                } elseif ($entry['rating'] === 'thumbs_down') {
                    $negative_ratings++;
                }
            }

            // Tally sources
            if (isset($entry['sources'])) {
                $source_name = $entry['sources'];
                // Normalize source names (e.g., group different file names)
                if (0 === strpos($source_name, __('File:', 'awesomebot'))) { // PHP 7.4 compatible
                    $source_name = __('File', 'awesomebot');
                } elseif (0 === strpos($source_name, __('Retrieved Context', 'awesomebot'))) { // PHP 7.4 compatible
                    // Keep 'Retrieved Context (...)' as is, or generalize further?
                    // For now, keep detail, but maybe generalize later if needed.
                    // Example generalization: $source_name = __('Retrieved Context', 'awesomebot');
                }
                $sources_tally[$source_name] = ($sources_tally[$source_name] ?? 0) + 1;
            }
        }

        $unanswered_queries = $total_queries - $successful_answers;
        $total_rated = $positive_ratings + $negative_ratings;

        // Calculate rates, handling division by zero.
        $success_rate = $total_queries > 0 ? round(($successful_answers / $total_queries) * 100, 1) : 0.0;
        $unanswered_rate = $total_queries > 0 ? round(($unanswered_queries / $total_queries) * 100, 1) : 0.0;
        $positive_rating_rate = $total_rated > 0 ? round(($positive_ratings / $total_rated) * 100, 1) : 0.0;
        $negative_rating_rate = $total_rated > 0 ? round(($negative_ratings / $total_rated) * 100, 1) : 0.0;

        // Determine most common source.
        $most_common_source = __('N/A', 'awesomebot');
        if (!empty($sources_tally)) {
            arsort($sources_tally); // Sort by count descending
            $most_common_source_key = key($sources_tally); // Get the key (name) of the first element

            // If 'None' is the most common, but others exist, show the next most common.
            if ($most_common_source_key === __('None', 'awesomebot') && count($sources_tally) > 1) {
                 reset($sources_tally); // Reset pointer
                 next($sources_tally); // Move to the second element
                 $most_common_source_key = key($sources_tally);
            }
             $most_common_source = $most_common_source_key ?: __('N/A', 'awesomebot');
        }

        $stats = [
            'total_queries'        => $total_queries,
            'successful_answers'   => $successful_answers,
            'unanswered_queries'   => $unanswered_queries,
            'success_rate'         => $success_rate,
            'unanswered_rate'      => $unanswered_rate,
            'positive_ratings'     => $positive_ratings,
            'negative_ratings'     => $negative_ratings,
            'positive_rating_rate' => $positive_rating_rate,
            'negative_rating_rate' => $negative_rating_rate,
            'most_common_source'   => $most_common_source,
        ];

        /**
         * Filters the calculated report statistics.
         *
         * @since 1.1.0
         * @param array $stats   The calculated statistics array.
         * @param array $history The chat history array used for calculation.
         */
        return (array) apply_filters('awesomebot_reports_stats', $stats, $history);
    }

} // End class AwesomeBot_Reports